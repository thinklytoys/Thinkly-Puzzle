package com.mondrian.puzzle.ui.screens

import androidx.compose.ui.geometry.Offset
import com.mondrian.puzzle.viewmodel.DragState
import kotlin.math.roundToInt

/** The board's on-screen position and cell size, captured via onGloballyPositioned
 * so drag gestures elsewhere (tray, board) can compute which cell a finger is over. */
data class BoardGeom(val topLeftInWindow: Offset, val cellPx: Float)

/** Given the current drag state and the board's geometry, find the board cell
 * the piece's top-left would land on if dropped now (clamped to the board). */
fun computeTargetCell(
    ds: DragState,
    geom: BoardGeom,
    boardSize: Int
): Pair<Int, Int>? {
    val pieceTopLeftInWindow = ds.fingerPosInWindow - ds.grabOffset
    val localX = pieceTopLeftInWindow.x - geom.topLeftInWindow.x
    val localY = pieceTopLeftInWindow.y - geom.topLeftInWindow.y
    val gx = (localX / geom.cellPx).roundToInt()
    val gy = (localY / geom.cellPx).roundToInt()
    if (gx < -2 || gy < -2 || gx > boardSize + 2 || gy > boardSize + 2) return null
    return gx.coerceIn(0, boardSize - 1) to gy.coerceIn(0, boardSize - 1)
}
