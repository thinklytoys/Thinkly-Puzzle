package com.mondrian.puzzle.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.HelpOutline
import androidx.compose.material.icons.filled.Insights
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.mondrian.puzzle.R
import com.mondrian.puzzle.data.ProgressStore
import com.mondrian.puzzle.ui.theme.AccentGold
import com.mondrian.puzzle.ui.theme.CardSurface
import com.mondrian.puzzle.ui.theme.GridLine
import com.mondrian.puzzle.ui.theme.InkBlack
import com.mondrian.puzzle.ui.theme.MutedText

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LevelSelectScreen(
    onLevelSelected: (Int) -> Unit,
    onOpenHelp: () -> Unit,
    onOpenStats: () -> Unit
) {
    val context = LocalContext.current
    val completed = remember { ProgressStore.getCompletedLevels(context) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Image(
                        painter = painterResource(id = R.drawable.logo_thinkly),
                        contentDescription = "Thinkly",
                        modifier = Modifier.height(32.dp)
                    )
                },
                actions = {
                    IconButton(onClick = onOpenStats) {
                        Icon(Icons.Filled.Insights, contentDescription = "Your stats")
                    }
                    IconButton(onClick = onOpenHelp) {
                        Icon(Icons.AutoMirrored.Filled.HelpOutline, contentDescription = "How to play")
                    }
                }
            )
        }
    ) { padding ->
        LazyVerticalGrid(
            columns = GridCells.Fixed(5),
            contentPadding = PaddingValues(12.dp),
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            items(88) { idx ->
                val level = idx + 1
                val unlocked = level == 1 || completed.contains(level - 1)
                val isDone = completed.contains(level)
                Box(
                    modifier = Modifier
                        .padding(6.dp)
                        .aspectRatio(1f)
                        .clip(RoundedCornerShape(10.dp))
                        .background(if (isDone) AccentGold.copy(alpha = 0.18f) else CardSurface)
                        .clickable(enabled = unlocked) { onLevelSelected(level) },
                    contentAlignment = Alignment.Center
                ) {
                    if (unlocked) {
                        Text(
                            text = level.toString(),
                            color = if (isDone) AccentGold else InkBlack,
                            fontWeight = if (isDone) FontWeight.Bold else FontWeight.Normal
                        )
                    } else {
                        Icon(
                            Icons.Filled.Lock,
                            contentDescription = "Locked",
                            tint = MutedText,
                            modifier = Modifier.padding(4.dp)
                        )
                    }
                }
            }
        }
    }
}
