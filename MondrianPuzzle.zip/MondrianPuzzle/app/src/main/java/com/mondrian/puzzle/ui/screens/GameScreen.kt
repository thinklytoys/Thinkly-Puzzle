package com.mondrian.puzzle.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInWindow
import androidx.compose.ui.unit.dp
import com.mondrian.puzzle.data.PIECE_COLORS
import com.mondrian.puzzle.ui.theme.MutedText
import com.mondrian.puzzle.viewmodel.GameViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GameScreen(
    levelNumber: Int,
    vm: GameViewModel,
    onBack: () -> Unit,
    onNextLevel: (Int) -> Unit
) {
    LaunchedEffect(levelNumber) {
        vm.loadLevel(levelNumber)
    }
    val engine = vm.engine
    // Reading boardVersion here ties GameScreen's recomposition (and therefore the
    // piece tray and win-check) to every placement/rotation/reset mutation, even
    // ones that don't otherwise change dragState.
    @Suppress("UNUSED_VARIABLE") val boardVersionTick = vm.boardVersion

    var rootOriginInWindow by remember { mutableStateOf(Offset.Zero) }
    var boardGeom by remember { mutableStateOf<BoardGeom?>(null) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Level $levelNumber") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(onClick = { vm.resetLevel() }) {
                        Icon(Icons.Filled.Refresh, contentDescription = "Reset")
                    }
                }
            )
        }
    ) { padding ->
        if (engine == null) return@Scaffold

        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .onGloballyPositioned { rootOriginInWindow = it.positionInWindow() }
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                BoardView(
                    vm = vm,
                    onGeomChanged = { boardGeom = it },
                    modifier = Modifier.fillMaxWidth()
                )

                Text(
                    text = "Drag a piece onto the board \u00b7 double-tap to rotate",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MutedText,
                    modifier = Modifier.padding(vertical = 10.dp)
                )

                PieceTray(
                    vm = vm,
                    pieces = vm.unplacedPieces(),
                    boardGeom = boardGeom,
                    boardSize = engine.boardSize,
                    modifier = Modifier.fillMaxWidth().weight(1f, fill = false)
                )
            }

            // floating ghost of the piece currently being dragged
            val ds = vm.dragState
            if (ds != null && boardGeom != null) {
                val piece = engine.pieces.first { it.piece.id == ds.pieceId }
                val w = piece.piece.width(ds.rotated)
                val h = piece.piece.height(ds.rotated)
                val cellPx = boardGeom!!.cellPx
                val topLeftInWindow = ds.fingerPosInWindow - ds.grabOffset
                val localOffset = topLeftInWindow - rootOriginInWindow
                val density = androidx.compose.ui.platform.LocalDensity.current
                val color = Color(PIECE_COLORS[(piece.piece.id - 1) % PIECE_COLORS.size])
                Box(
                    modifier = Modifier
                        .offset(
                            x = with(density) { localOffset.x.toDp() },
                            y = with(density) { localOffset.y.toDp() }
                        )
                        .size(
                            with(density) { (w * cellPx).toDp() },
                            with(density) { (h * cellPx).toDp() }
                        )
                        .clip(RoundedCornerShape(10.dp))
                        .background(color.copy(alpha = 0.9f))
                )
            }
        }

        if (vm.won) {
            AlertDialog(
                onDismissRequest = { },
                title = { Text("Solved!") },
                text = { Text("Level $levelNumber complete.") },
                confirmButton = {
                    TextButton(onClick = {
                        if (levelNumber < 88) onNextLevel(levelNumber + 1) else onBack()
                    }) {
                        Text(if (levelNumber < 88) "Next level" else "Done")
                    }
                },
                dismissButton = {
                    TextButton(onClick = onBack) {
                        Text("Level select")
                    }
                }
            )
        }
    }
}
