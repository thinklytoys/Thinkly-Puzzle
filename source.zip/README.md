# Blockwright

An 8x8 rectangle-dissection puzzle game (88 levels, easy → hard), built with
Kotlin + Jetpack Compose. Levels are real data extracted from your physical
puzzle booklet photos and verified solvable by an exact-cover solver.

## Opening the project

1. Open Android Studio (Hedgehog/2023.1 or newer recommended).
2. **File → Open** and select this folder (`MondrianPuzzle`).
3. Let Gradle sync — it will download the Gradle distribution and all
   dependencies automatically on first sync (needs internet access).
4. Run on an emulator or device (minSdk 24 / Android 7.0+).

If Android Studio doesn't detect the Gradle wrapper jar, use
**File → Sync Project with Gradle Files**, or let Studio regenerate the
wrapper — it will prompt automatically.

## How it plays

- **Drag and drop**: press and drag a piece from the tray onto the board.
  While dragging, the target cells preview in green (valid) or red
  (would overlap / off-board) so you always see where it'll land before
  you let go.
- **Move a placed piece**: drag it directly from the board to a new spot.
- **Rotate**: double-tap any piece (in the tray or already on the board)
  to spin it 90°. If it no longer fits at its current spot, it's put back
  as it was.
- **Reset**: the refresh icon in the top bar clears the level back to just
  the 3 fixed (dark) blocks.
- A level is solved when every cell on the board is covered — the fixed
  blocks plus all 8 movable pieces, no gaps or overlaps.

## Structure

```
data/          Piece/level models, board logic (GameEngine), JSON loading,
               SharedPreferences-based progress tracking
viewmodel/     GameViewModel — board state + drag-and-drop state machine
ui/screens/    LevelSelectScreen, GameScreen, BoardView (Canvas rendering +
               gesture handling), PieceTray
ui/theme/      Color palette (soft pastel tiles), type, Material theme
assets/levels.json   All 88 levels' fixed-block layouts
```

## Notes

- Visual style: rounded, gapped tiles in a soft pastel palette, inspired by
  the Almanac app's board look, with the 3 always-present obstacle blocks
  rendered in dark charcoal so they read as fixed.
- Levels 1-30 are tagged "easy", 31-60 "medium", 61-88 "hard" (based on
  their order in your booklet, which already runs easy to difficult).
- Progress (which levels you've completed) is saved on-device and unlocks
  the next level automatically.
