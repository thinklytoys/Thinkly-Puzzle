package com.mondrian.puzzle

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.mondrian.puzzle.data.OnboardingStore
import com.mondrian.puzzle.ui.screens.GameScreen
import com.mondrian.puzzle.ui.screens.LevelSelectScreen
import com.mondrian.puzzle.ui.screens.OnboardingScreen
import com.mondrian.puzzle.ui.screens.StatsScreen
import com.mondrian.puzzle.ui.theme.MondrianPuzzleTheme
import com.mondrian.puzzle.viewmodel.GameViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MondrianPuzzleTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    AppNavHost()
                }
            }
        }
    }
}

@Composable
fun AppNavHost() {
    val navController = rememberNavController()
    val gameViewModel: GameViewModel = viewModel()
    val context = LocalContext.current
    val startDestination = if (OnboardingStore.hasSeenOnboarding(context)) "levelSelect" else "onboarding"

    NavHost(navController = navController, startDestination = startDestination) {
        composable("onboarding") {
            OnboardingScreen(onFinished = {
                if (navController.previousBackStackEntry != null) {
                    navController.popBackStack()
                } else {
                    navController.navigate("levelSelect") {
                        popUpTo("onboarding") { inclusive = true }
                    }
                }
            })
        }
        composable("levelSelect") {
            LevelSelectScreen(
                onLevelSelected = { level -> navController.navigate("game/$level") },
                onOpenHelp = { navController.navigate("onboarding") },
                onOpenStats = { navController.navigate("stats") }
            )
        }
        composable("stats") {
            StatsScreen(onBack = { navController.popBackStack() })
        }
        composable(
            route = "game/{level}",
            arguments = listOf(navArgument("level") { type = NavType.IntType })
        ) { backStackEntry ->
            val level = backStackEntry.arguments?.getInt("level") ?: 1
            GameScreen(
                levelNumber = level,
                vm = gameViewModel,
                onBack = { navController.popBackStack("levelSelect", inclusive = false) },
                onNextLevel = { next ->
                    navController.navigate("game/$next") {
                        popUpTo("levelSelect")
                    }
                }
            )
        }
    }
}
