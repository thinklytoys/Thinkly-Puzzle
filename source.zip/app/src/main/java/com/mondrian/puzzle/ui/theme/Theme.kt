package com.mondrian.puzzle.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val LightColors = lightColorScheme(
    primary = InkBlack,
    onPrimary = Paper,
    background = Paper,
    onBackground = InkBlack,
    surface = CardSurface,
    onSurface = InkBlack,
    secondary = AccentGold,
)

@Composable
fun MondrianPuzzleTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = LightColors,
        typography = MondrianTypography,
        content = content
    )
}
