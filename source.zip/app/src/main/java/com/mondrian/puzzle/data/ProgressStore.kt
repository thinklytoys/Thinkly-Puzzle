package com.mondrian.puzzle.data

import android.content.Context

object ProgressStore {
    private const val PREFS = "mondrian_progress"
    private const val KEY_COMPLETED = "completed_levels"

    fun getCompletedLevels(context: Context): Set<Int> {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val raw = prefs.getStringSet(KEY_COMPLETED, emptySet()) ?: emptySet()
        return raw.mapNotNull { it.toIntOrNull() }.toSet()
    }

    fun markCompleted(context: Context, level: Int) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val current = getCompletedLevels(context).toMutableSet()
        current.add(level)
        prefs.edit().putStringSet(KEY_COMPLETED, current.map { it.toString() }.toSet()).apply()
    }

    fun isUnlocked(context: Context, level: Int): Boolean {
        if (level == 1) return true
        return getCompletedLevels(context).contains(level - 1)
    }
}
