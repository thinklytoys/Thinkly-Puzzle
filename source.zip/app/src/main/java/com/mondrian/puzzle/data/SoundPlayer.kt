package com.mondrian.puzzle.data

import android.content.Context
import android.media.AudioAttributes
import android.media.SoundPool
import com.mondrian.puzzle.R

/** Lightweight sound effects: soft tick (pickup/rotate), place (successful
 * drop), win (level solved). Loaded once and reused via SoundPool, which is
 * built for exactly this -- many short, overlapping UI sounds with low
 * latency. Every call is wrapped defensively; audio is a nice-to-have and
 * must never be able to crash or block gameplay. */
object SoundPlayer {
    private var soundPool: SoundPool? = null
    private var tickId = 0
    private var placeId = 0
    private var winId = 0
    private var loaded = false
    private var enabled = true

    fun init(context: Context) {
        if (soundPool != null) return
        try {
            val attrs = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_GAME)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()
            val pool = SoundPool.Builder()
                .setMaxStreams(4)
                .setAudioAttributes(attrs)
                .build()
            soundPool = pool
            val ctx = context.applicationContext
            tickId = pool.load(ctx, R.raw.sfx_tick, 1)
            placeId = pool.load(ctx, R.raw.sfx_place, 1)
            winId = pool.load(ctx, R.raw.sfx_win, 1)
            loaded = true
        } catch (_: Throwable) {
            soundPool = null
        }
    }

    fun setEnabled(value: Boolean) {
        enabled = value
    }

    fun playTick() = play(tickId, 0.5f)
    fun playPlace() = play(placeId, 0.7f)
    fun playWin() = play(winId, 0.8f)

    private fun play(soundId: Int, volume: Float) {
        if (!enabled || !loaded) return
        try {
            soundPool?.play(soundId, volume, volume, 1, 0, 1f)
        } catch (_: Throwable) {
            // never let audio failures affect gameplay
        }
    }
}
