package com.mondrian.puzzle.ui.theme

import androidx.compose.ui.graphics.Color

val Paper = Color(0xFFF7F5F0)
val InkBlack = Color(0xFF1C1B18)
val GridLine = Color(0xFFB9B5AA)
val CardSurface = Color(0xFFFFFFFF)
val AccentGold = Color(0xFFC98A2C)
val MutedText = Color(0xFF6B675E)
