package com.mondrian.puzzle.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInWindow
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mondrian.puzzle.data.PIECE_COLORS
import com.mondrian.puzzle.data.PlacedPiece
import com.mondrian.puzzle.ui.theme.CardSurface
import com.mondrian.puzzle.ui.theme.GridLine
import com.mondrian.puzzle.ui.theme.MutedText
import com.mondrian.puzzle.viewmodel.GameViewModel

@Composable
fun PieceTray(
    vm: GameViewModel,
    pieces: List<PlacedPiece>,
    boardGeom: BoardGeom?,
    boardSize: Int,
    modifier: Modifier = Modifier
) {
    val dragState = vm.dragState

    LazyVerticalGrid(
        columns = GridCells.Fixed(4),
        modifier = modifier,
        contentPadding = PaddingValues(8.dp)
    ) {
        items(pieces, key = { it.piece.id }) { p ->
            var originInWindow by remember { mutableStateOf(Offset.Zero) }
            val isDragging = dragState?.pieceId == p.piece.id && !dragState.fromBoard
            val color = Color(PIECE_COLORS[(p.piece.id - 1) % PIECE_COLORS.size])
            // The drag gesture coroutine below is launched once (keyed only on the
            // stable piece id) and would otherwise permanently capture whatever
            // boardGeom was at that moment -- which is null before the board has
            // finished its first layout pass. rememberUpdatedState keeps a live
            // reference so onDragEnd always sees the current value instead.
            val latestBoardGeom by rememberUpdatedState(boardGeom)

            Column(
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    modifier = Modifier
                        .padding(6.dp)
                        .size(64.dp)
                        .onGloballyPositioned { coords -> originInWindow = coords.positionInWindow() }
                        .clip(RoundedCornerShape(14.dp))
                        .background(CardSurface)
                        .alpha(if (isDragging) 0.25f else 1f)
                        .pointerInput(p.piece.id) {
                            detectTapGestures(
                                onDoubleTap = { vm.toggleTrayRotation(p.piece.id) }
                            )
                        }
                        .pointerInput(p.piece.id) {
                            detectDragGestures(
                                onDragStart = { offset ->
                                    vm.startDragFromTray(
                                        p.piece.id,
                                        fingerPosInWindow = originInWindow + offset
                                    )
                                },
                                onDrag = { change, _ ->
                                    change.consume()
                                    vm.updateDrag(originInWindow + change.position)
                                },
                                onDragEnd = {
                                    val ds = vm.dragState
                                    val geomNow = latestBoardGeom
                                    if (ds != null && geomNow != null) {
                                        val wPx = p.piece.width(ds.rotated) * geomNow.cellPx
                                        val hPx = p.piece.height(ds.rotated) * geomNow.cellPx
                                        val target = computeTargetCell(ds, geomNow, boardSize, wPx, hPx)
                                        vm.endDrag(target?.first, target?.second)
                                    } else {
                                        vm.cancelDrag()
                                    }
                                },
                                onDragCancel = { vm.cancelDrag() }
                            )
                        },
                    contentAlignment = Alignment.Center
                ) {
                    val w = p.piece.width(p.rotated)
                    val h = p.piece.height(p.rotated)
                    val maxDim = maxOf(w, h).toFloat()
                    Box(
                        modifier = Modifier
                            .size((44.dp.value * (w / maxDim)).dp, (44.dp.value * (h / maxDim)).dp)
                            .clip(RoundedCornerShape(6.dp))
                            .background(color)
                    )
                }
                // size label, e.g. "2x3" -- always shows the base (un-rotated) shape
                // so it stays a stable reference regardless of current orientation
                Text(
                    text = "${p.piece.baseW}\u00d7${p.piece.baseH}",
                    style = MaterialTheme.typography.bodyMedium,
                    fontWeight = FontWeight.Medium,
                    fontSize = 11.sp,
                    color = MutedText
                )
            }
        }
    }
}
