package com.mondrian.puzzle.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mondrian.puzzle.data.ALL_ACHIEVEMENTS
import com.mondrian.puzzle.data.Achievement
import com.mondrian.puzzle.data.AchievementsStore
import com.mondrian.puzzle.data.AnalyticsStore
import com.mondrian.puzzle.data.CognitiveReport
import com.mondrian.puzzle.data.CognitiveSkill
import com.mondrian.puzzle.data.StreakStore
import com.mondrian.puzzle.ui.theme.AccentGold
import com.mondrian.puzzle.ui.theme.CardSurface
import com.mondrian.puzzle.ui.theme.InkBlack
import com.mondrian.puzzle.ui.theme.MutedText
import com.mondrian.puzzle.ui.theme.Paper
import com.mondrian.puzzle.ui.theme.ThinklyHeader
import com.mondrian.puzzle.ui.theme.ThinklyIconButton

@Composable
fun StatsScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val stats = remember { AnalyticsStore.getStatsSummary(context) }
    val currentStreak = remember { StreakStore.getCurrentStreak(context) }
    val longestStreak = remember { StreakStore.getLongestStreak(context) }
    val unlockedIds = remember { AchievementsStore.getUnlockedIds(context) }
    val cognitiveSkills = remember { CognitiveReport.compute(context) }

    Column(modifier = Modifier.fillMaxSize().background(Paper)) {
        ThinklyHeader(
            modifier = Modifier.fillMaxWidth(),
            navigationIcon = {
                ThinklyIconButton(Icons.AutoMirrored.Filled.ArrowBack, "Back", onClick = onBack)
            },
            title = {
                Text(
                    "Your thinking stats",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = InkBlack
                )
            }
        )
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(20.dp)
        ) {
            Row(modifier = Modifier.fillMaxWidth()) {
                StatCard(label = "Current streak", value = "$currentStreak day${if (currentStreak == 1) "" else "s"}", modifier = Modifier.weight(1f))
                Spacer(modifier = Modifier.width(12.dp))
                StatCard(label = "Longest streak", value = "$longestStreak day${if (longestStreak == 1) "" else "s"}", modifier = Modifier.weight(1f))
            }
            Spacer(modifier = Modifier.height(12.dp))

            if (stats.totalSolved == 0) {
                Text(
                    "Solve a few puzzles and your stats will show up here.",
                    color = MutedText,
                    style = MaterialTheme.typography.bodyLarge,
                    modifier = Modifier.padding(top = 12.dp)
                )
            } else {
                Row(modifier = Modifier.fillMaxWidth()) {
                    StatCard(label = "Solved", value = "${stats.totalSolved}/88", modifier = Modifier.weight(1f))
                    Spacer(modifier = Modifier.width(12.dp))
                    StatCard(label = "Avg. time", value = formatDuration(stats.avgTimeMs), modifier = Modifier.weight(1f))
                }
                Spacer(modifier = Modifier.height(12.dp))
                Row(modifier = Modifier.fillMaxWidth()) {
                    StatCard(
                        label = "Fastest solve",
                        value = stats.fastestSolveMs?.let { formatDuration(it) } ?: "-",
                        modifier = Modifier.weight(1f)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    StatCard(label = "Total attempts", value = "${stats.totalAttempts}", modifier = Modifier.weight(1f))
                }
                Spacer(modifier = Modifier.height(12.dp))
                Row(modifier = Modifier.fillMaxWidth()) {
                    StatCard(label = "Hints used", value = "${stats.totalHints}", modifier = Modifier.weight(1f))
                    Spacer(modifier = Modifier.width(12.dp))
                    StatCard(label = "Blocks removed", value = "${stats.totalReturns}", modifier = Modifier.weight(1f))
                }

                Spacer(modifier = Modifier.height(24.dp))
                Text("How you compare", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = InkBlack)
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    "Measured against a built-in benchmark of typical solve times — not live data from other players (yet).",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MutedText
                )
                Spacer(modifier = Modifier.height(12.dp))

                stats.timePercentile?.let {
                    InsightRow("You solve puzzles faster than about $it% of typical players.")
                }
                stats.attemptsPercentile?.let {
                    InsightRow("You use fewer attempts than about $it% of typical players.")
                }
                stats.improvementPct?.let { pct ->
                    if (pct > 0) {
                        InsightRow("You've gotten about $pct% faster since your first few solves.")
                    } else if (pct < 0) {
                        InsightRow("Your recent solves have taken a bit longer than your first ones — happens on harder levels.")
                    }
                }
            }

            if (cognitiveSkills.isNotEmpty()) {
                Spacer(modifier = Modifier.height(24.dp))
                Text("Brain engagement", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = InkBlack)
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    "A gamified estimate based on your play patterns \u2014 attempts, speed, hints, and consistency. Not a medical or scientific measurement.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MutedText
                )
                Spacer(modifier = Modifier.height(14.dp))
                for (skill in cognitiveSkills) {
                    CognitiveSkillRow(skill)
                    Spacer(modifier = Modifier.height(12.dp))
                }
            }

            Spacer(modifier = Modifier.height(24.dp))
            Text(
                "Achievements (${unlockedIds.size}/${ALL_ACHIEVEMENTS.size})",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = InkBlack
            )
            Spacer(modifier = Modifier.height(10.dp))
            LazyVerticalGrid(
                columns = GridCells.Fixed(3),
                modifier = Modifier
                    .fillMaxWidth()
                    .height((((ALL_ACHIEVEMENTS.size + 2) / 3) * 110).dp)
            ) {
                items(ALL_ACHIEVEMENTS) { achievement ->
                    AchievementBadge(achievement = achievement, unlocked = achievement.id in unlockedIds)
                }
            }
        }
    }
}

@Composable
private fun AchievementBadge(achievement: Achievement, unlocked: Boolean) {
    Column(
        modifier = Modifier
            .padding(6.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(if (unlocked) CardSurface else MutedText.copy(alpha = 0.08f))
            .padding(10.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            modifier = Modifier
                .size(40.dp)
                .clip(CircleShape)
                .background(if (unlocked) AccentGold.copy(alpha = 0.2f) else MutedText.copy(alpha = 0.12f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                if (unlocked) Icons.Filled.EmojiEvents else Icons.Filled.Lock,
                contentDescription = null,
                tint = if (unlocked) AccentGold else MutedText.copy(alpha = 0.5f),
                modifier = Modifier.size(20.dp)
            )
        }
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            achievement.title,
            style = MaterialTheme.typography.labelLarge,
            fontWeight = FontWeight.SemiBold,
            color = if (unlocked) InkBlack else MutedText,
            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
            maxLines = 2
        )
        Text(
            achievement.description,
            style = MaterialTheme.typography.bodyMedium,
            color = MutedText,
            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
            maxLines = 2,
            fontSize = 10.sp
        )
    }
}

@Composable
private fun CognitiveSkillRow(skill: CognitiveSkill) {
    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(skill.name, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.SemiBold, color = InkBlack)
            Text("${skill.score}", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold, color = AccentGold)
        }
        Spacer(modifier = Modifier.height(4.dp))
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(8.dp)
                .clip(RoundedCornerShape(4.dp))
                .background(MutedText.copy(alpha = 0.15f))
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth(skill.score / 100f)
                    .height(8.dp)
                    .clip(RoundedCornerShape(4.dp))
                    .background(AccentGold)
            )
        }
        Spacer(modifier = Modifier.height(4.dp))
        Text(skill.description, style = MaterialTheme.typography.bodyMedium, color = MutedText)
    }
}

@Composable
private fun StatCard(label: String, value: String, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(14.dp))
            .background(CardSurface)
            .padding(16.dp)
    ) {
        Text(value, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = InkBlack)
        Text(label, style = MaterialTheme.typography.bodyMedium, color = MutedText)
    }
}

@Composable
private fun InsightRow(text: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(AccentGold.copy(alpha = 0.12f))
            .padding(14.dp)
    ) {
        Text(text, style = MaterialTheme.typography.bodyLarge, color = InkBlack)
    }
}

private fun formatDuration(ms: Long): String {
    val totalSec = ms / 1000
    val m = totalSec / 60
    val s = totalSec % 60
    return if (m > 0) "${m}m ${s}s" else "${s}s"
}
