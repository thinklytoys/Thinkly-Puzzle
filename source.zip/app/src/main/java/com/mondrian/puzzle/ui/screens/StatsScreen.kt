package com.mondrian.puzzle.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.mondrian.puzzle.data.AnalyticsStore
import com.mondrian.puzzle.ui.theme.AccentGold
import com.mondrian.puzzle.ui.theme.CardSurface
import com.mondrian.puzzle.ui.theme.InkBlack
import com.mondrian.puzzle.ui.theme.MutedText

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StatsScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val stats = remember { AnalyticsStore.getStatsSummary(context) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Your thinking stats") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(20.dp)
        ) {
            if (stats.totalSolved == 0) {
                Text(
                    "Solve a few puzzles and your stats will show up here.",
                    color = MutedText,
                    style = MaterialTheme.typography.bodyLarge
                )
                return@Scaffold
            }

            Row(modifier = Modifier.fillMaxWidth()) {
                StatCard(label = "Solved", value = "${stats.totalSolved}/88", modifier = Modifier.weight(1f))
                Spacer(modifier = Modifier.width(12.dp))
                StatCard(label = "Avg. time", value = formatDuration(stats.avgTimeMs), modifier = Modifier.weight(1f))
            }
            Spacer(modifier = Modifier.height(12.dp))
            Row(modifier = Modifier.fillMaxWidth()) {
                StatCard(
                    label = "Fastest solve",
                    value = stats.fastestSolveMs?.let { formatDuration(it) } ?: "-",
                    modifier = Modifier.weight(1f)
                )
                Spacer(modifier = Modifier.width(12.dp))
                StatCard(label = "Total attempts", value = "${stats.totalAttempts}", modifier = Modifier.weight(1f))
            }

            Spacer(modifier = Modifier.height(24.dp))
            Text("How you compare", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = InkBlack)
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                "Measured against a built-in benchmark of typical solve times — not live data from other players (yet).",
                style = MaterialTheme.typography.bodyMedium,
                color = MutedText
            )
            Spacer(modifier = Modifier.height(12.dp))

            stats.timePercentile?.let {
                InsightRow("You solve puzzles faster than about $it% of typical players.")
            }
            stats.attemptsPercentile?.let {
                InsightRow("You use fewer attempts than about $it% of typical players.")
            }
            stats.improvementPct?.let { pct ->
                if (pct > 0) {
                    InsightRow("You've gotten about $pct% faster since your first few solves.")
                } else if (pct < 0) {
                    InsightRow("Your recent solves have taken a bit longer than your first ones — happens on harder levels.")
                }
            }
        }
    }
}

@Composable
private fun StatCard(label: String, value: String, modifier: Modifier = Modifier) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(14.dp))
            .background(CardSurface)
            .padding(16.dp)
    ) {
        Text(value, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = InkBlack)
        Text(label, style = MaterialTheme.typography.bodyMedium, color = MutedText)
    }
}

@Composable
private fun InsightRow(text: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp)
            .clip(RoundedCornerShape(12.dp))
            .background(AccentGold.copy(alpha = 0.12f))
            .padding(14.dp)
    ) {
        Text(text, style = MaterialTheme.typography.bodyLarge, color = InkBlack)
    }
}

private fun formatDuration(ms: Long): String {
    val totalSec = ms / 1000
    val m = totalSec / 60
    val s = totalSec % 60
    return if (m > 0) "${m}m ${s}s" else "${s}s"
}
