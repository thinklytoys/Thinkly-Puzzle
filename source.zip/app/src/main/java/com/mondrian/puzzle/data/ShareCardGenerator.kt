package com.mondrian.puzzle.data

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileOutputStream

/** Builds a shareable PNG showing the solved board and a few stats, and
 * launches Android's share sheet with it. Drawn with plain android.graphics
 * primitives (not Compose) so it doesn't depend on any newer/experimental
 * bitmap-capture API. */
object ShareCardGenerator {

    fun shareSolvedLevel(
        context: Context,
        levelNumber: Int,
        engine: GameEngine,
        timeMs: Long?,
        attempts: Int?,
        hints: Int?
    ) {
        try {
            val bitmap = buildCard(levelNumber, engine, timeMs, attempts, hints)
            val dir = File(context.cacheDir, "shared_images").apply { mkdirs() }
            val file = File(dir, "thinkly_level_$levelNumber.png")
            FileOutputStream(file).use { out ->
                bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
            }
            val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "image/png"
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_TEXT, "I solved level $levelNumber in Thinkly Puzzle!")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(Intent.createChooser(intent, "Share your solve").apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            })
        } catch (_: Throwable) {
            // sharing is a nice-to-have; never let a failure here crash the app
        }
    }

    private fun buildCard(
        levelNumber: Int,
        engine: GameEngine,
        timeMs: Long?,
        attempts: Int?,
        hints: Int?
    ): Bitmap {
        val w = 900
        val h = 1150
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bmp)

        val paperColor = Color.parseColor("#F7F5F0")
        val inkColor = Color.parseColor("#1C1B18")
        val mutedColor = Color.parseColor("#6B675E")
        val goldColor = Color.parseColor("#C98A2C")
        val fixedColor = Color.parseColor("#3A362F")

        canvas.drawColor(paperColor)

        val paint = Paint(Paint.ANTI_ALIAS_FLAG)

        // Header: wordmark + level
        paint.color = inkColor
        paint.textSize = 54f
        paint.typeface = Typeface.create(Typeface.DEFAULT_BOLD, Typeface.BOLD)
        canvas.drawText("thinkly", 48f, 100f, paint)

        paint.color = goldColor
        paint.textSize = 40f
        canvas.drawText("Level $levelNumber \u00b7 Solved!", 48f, 160f, paint)

        // Board area
        val boardSize = engine.boardSize
        val boardMargin = 60f
        val boardTop = 220f
        val boardPx = w - boardMargin * 2
        val cell = boardPx / boardSize

        val blockPaint = Paint(Paint.ANTI_ALIAS_FLAG)
        val rect = RectF()
        val cornerRadius = cell * 0.16f
        val gap = cell * 0.05f

        for (b in engine.level.fixedBlocks) {
            rect.set(
                boardMargin + b.x * cell + gap,
                boardTop + b.y * cell + gap,
                boardMargin + (b.x + b.w) * cell - gap,
                boardTop + (b.y + b.h) * cell - gap
            )
            blockPaint.color = fixedColor
            canvas.drawRoundRect(rect, cornerRadius, cornerRadius, blockPaint)
        }
        for (p in engine.pieces.filter { it.placed }) {
            val pw = p.piece.width(p.rotated)
            val ph = p.piece.height(p.rotated)
            rect.set(
                boardMargin + p.x * cell + gap,
                boardTop + p.y * cell + gap,
                boardMargin + (p.x + pw) * cell - gap,
                boardTop + (p.y + ph) * cell - gap
            )
            blockPaint.color = argbFromPacked(PIECE_COLORS[(p.piece.id - 1) % PIECE_COLORS.size])
            canvas.drawRoundRect(rect, cornerRadius, cornerRadius, blockPaint)
        }

        // Stats row below the board
        var statsY = boardTop + boardPx + 80f
        paint.color = inkColor
        paint.textSize = 38f
        paint.typeface = Typeface.create(Typeface.DEFAULT_BOLD, Typeface.BOLD)

        val statParts = mutableListOf<String>()
        timeMs?.let { statParts.add(formatMs(it)) }
        attempts?.let { statParts.add("$it attempt${if (it == 1) "" else "s"}") }
        if (hints != null && hints > 0) statParts.add("$hints hint${if (hints == 1) "" else "s"}")
        val statsLine = statParts.joinToString("   \u00b7   ")
        canvas.drawText(statsLine, boardMargin, statsY, paint)

        statsY += 60f
        paint.color = mutedColor
        paint.textSize = 28f
        paint.typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
        canvas.drawText("A daily workout for your spatial thinking.", boardMargin, statsY, paint)

        return bmp
    }

    private fun formatMs(ms: Long): String {
        val totalSec = ms / 1000
        val m = totalSec / 60
        val s = totalSec % 60
        return if (m > 0) "${m}m ${s}s" else "${s}s"
    }

    /** Our piece palette is stored as 0xAARRGGBB Long values; convert to an
     * android.graphics.Color int. */
    private fun argbFromPacked(packed: Long): Int = packed.toInt()
}
