package com.mondrian.puzzle.data

import android.content.Context

data class Achievement(
    val id: String,
    val title: String,
    val description: String
)

val ALL_ACHIEVEMENTS = listOf(
    Achievement("first_solve", "First Steps", "Solve your first puzzle"),
    Achievement("one_attempt", "Perfectionist", "Solve a puzzle on your first attempt"),
    Achievement("speed_60", "Speed Runner", "Solve a puzzle in under a minute"),
    Achievement("no_hints_10", "Independent Thinker", "Solve 10 puzzles without a hint"),
    Achievement("halfway", "Halfway There", "Complete 44 levels"),
    Achievement("puzzle_master", "Puzzle Master", "Complete all 88 levels"),
    Achievement("streak_3", "Getting Warmed Up", "3-day play streak"),
    Achievement("streak_7", "One Week Strong", "7-day play streak"),
    Achievement("streak_30", "Habit Formed", "30-day play streak"),
)

object AchievementsStore {
    private const val PREFS = "mondrian_achievements"
    private const val KEY_UNLOCKED = "unlocked_ids"
    private const val KEY_NO_HINT_COUNT = "no_hint_solve_count"

    fun getUnlockedIds(context: Context): Set<String> {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getStringSet(KEY_UNLOCKED, emptySet()) ?: emptySet()
    }

    private fun unlock(context: Context, id: String, unlockedBefore: MutableSet<String>): Achievement? {
        if (id in unlockedBefore) return null
        unlockedBefore.add(id)
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putStringSet(KEY_UNLOCKED, unlockedBefore).apply()
        return ALL_ACHIEVEMENTS.firstOrNull { it.id == id }
    }

    /** Call right after recording a solve. Checks every condition and unlocks
     * whatever newly qualifies, returning just the newly-unlocked ones (empty
     * list if nothing new) so the UI can show a small celebration for them. */
    fun checkAfterSolve(
        context: Context,
        totalSolved: Int,
        hintsUsedThisLevel: Int,
        attemptsThisLevel: Int,
        solveTimeMs: Long,
        currentStreak: Int
    ): List<Achievement> {
        val unlocked = getUnlockedIds(context).toMutableSet()
        val newly = mutableListOf<Achievement>()

        fun tryUnlock(id: String) {
            unlock(context, id, unlocked)?.let { newly.add(it) }
        }

        if (totalSolved >= 1) tryUnlock("first_solve")
        if (totalSolved >= 44) tryUnlock("halfway")
        if (totalSolved >= 88) tryUnlock("puzzle_master")
        if (attemptsThisLevel == 1) tryUnlock("one_attempt")
        if (solveTimeMs < 60_000) tryUnlock("speed_60")
        if (currentStreak >= 3) tryUnlock("streak_3")
        if (currentStreak >= 7) tryUnlock("streak_7")
        if (currentStreak >= 30) tryUnlock("streak_30")

        if (hintsUsedThisLevel == 0) {
            val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            val count = prefs.getInt(KEY_NO_HINT_COUNT, 0) + 1
            prefs.edit().putInt(KEY_NO_HINT_COUNT, count).apply()
            if (count >= 10) tryUnlock("no_hints_10")
        }

        return newly
    }
}
