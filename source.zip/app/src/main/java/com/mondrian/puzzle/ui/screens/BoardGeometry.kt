package com.mondrian.puzzle.ui.screens

import androidx.compose.ui.geometry.Offset
import com.mondrian.puzzle.viewmodel.DragState
import kotlin.math.roundToInt

/** The board's on-screen position and cell size, captured via onGloballyPositioned
 * so drag gestures elsewhere (tray, board) can compute which cell a finger is over. */
data class BoardGeom(val topLeftInWindow: Offset, val cellPx: Float)

/** Given the current drag state and the board's geometry, find the board cell
 * the piece's top-left should land on if dropped now.
 *
 * The "still over the board, or off it" decision is made using the FINGER's
 * position (with a generous margin), not the piece's own corner math -- doing
 * it via the piece's corner scales badly for large pieces (a 3x5 block's
 * corner can shoot past a fixed threshold while the finger is still clearly
 * over the board). As long as the finger itself is on/near the board, we
 * always find a legal, fully-on-board spot for the piece (clamped using its
 * real width/height so it can never hang off an edge). Only when the finger
 * has genuinely left the board area do we report "no target" (which the
 * caller uses to snap the piece back to where it started). */
fun computeTargetCell(
    ds: DragState,
    geom: BoardGeom,
    boardSize: Int,
    pieceWidthPx: Float,
    pieceHeightPx: Float
): Pair<Int, Int>? {
    val boardWidthPx = geom.cellPx * boardSize
    val boardHeightPx = geom.cellPx * boardSize
    val margin = geom.cellPx * 1.0f // one cell of slack around the board edge

    val fingerLocal = ds.fingerPosInWindow - geom.topLeftInWindow
    val fingerOverBoard = fingerLocal.x >= -margin && fingerLocal.x <= boardWidthPx + margin &&
        fingerLocal.y >= -margin && fingerLocal.y <= boardHeightPx + margin
    if (!fingerOverBoard) return null

    val pieceCellsW = (pieceWidthPx / geom.cellPx).roundToInt().coerceIn(1, boardSize)
    val pieceCellsH = (pieceHeightPx / geom.cellPx).roundToInt().coerceIn(1, boardSize)

    val pieceTopLeftInWindow = ds.fingerPosInWindow - Offset(pieceWidthPx / 2f, pieceHeightPx / 2f)
    val localX = pieceTopLeftInWindow.x - geom.topLeftInWindow.x
    val localY = pieceTopLeftInWindow.y - geom.topLeftInWindow.y
    val gx = (localX / geom.cellPx).roundToInt().coerceIn(0, boardSize - pieceCellsW)
    val gy = (localY / geom.cellPx).roundToInt().coerceIn(0, boardSize - pieceCellsH)
    return gx to gy
}
