package com.mondrian.puzzle.data

import android.content.Context
import java.util.Calendar

/** Tracks a simple daily play streak: solving at least one level on a given
 * local calendar day counts as "played that day." Consecutive days extend
 * the streak; missing a day resets it. Uses Calendar (not java.time) since
 * this app's minSdk (24) is below java.time's native API 26 requirement. */
object StreakStore {
    private const val PREFS = "mondrian_streak"
    private const val KEY_LAST_DAY = "last_played_day_index"
    private const val KEY_CURRENT_STREAK = "current_streak"
    private const val KEY_LONGEST_STREAK = "longest_streak"

    private fun todayDayIndex(): Long {
        val cal = Calendar.getInstance()
        cal.set(Calendar.HOUR_OF_DAY, 0)
        cal.set(Calendar.MINUTE, 0)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        return cal.timeInMillis / 86_400_000L
    }

    /** Call when a level is solved. Returns the current streak count after
     * this update. Safe to call multiple times per day (only the first call
     * each day changes anything). */
    fun recordPlayToday(context: Context): Int {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val today = todayDayIndex()
        val lastDay = prefs.getLong(KEY_LAST_DAY, -1L)
        var streak = prefs.getInt(KEY_CURRENT_STREAK, 0)

        streak = when (lastDay) {
            today -> streak            // already played today, no change
            today - 1 -> streak + 1     // played yesterday -> extend streak
            else -> 1                   // gap of 2+ days (or first ever play) -> restart
        }

        val longest = maxOf(prefs.getInt(KEY_LONGEST_STREAK, 0), streak)
        prefs.edit()
            .putLong(KEY_LAST_DAY, today)
            .putInt(KEY_CURRENT_STREAK, streak)
            .putInt(KEY_LONGEST_STREAK, longest)
            .apply()
        return streak
    }

    /** Current streak for display. If the last played day was before
     * yesterday, the streak is effectively broken even though we only
     * formally reset the stored value the next time [recordPlayToday] runs --
     * so this reports 0 in that case rather than a stale number. */
    fun getCurrentStreak(context: Context): Int {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val today = todayDayIndex()
        val lastDay = prefs.getLong(KEY_LAST_DAY, -1L)
        val streak = prefs.getInt(KEY_CURRENT_STREAK, 0)
        return if (lastDay == today || lastDay == today - 1) streak else 0
    }

    fun getLongestStreak(context: Context): Int {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getInt(KEY_LONGEST_STREAK, 0)
    }
}
