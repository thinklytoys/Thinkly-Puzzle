@file:OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)

package com.mondrian.puzzle.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.mondrian.puzzle.R
import com.mondrian.puzzle.data.OnboardingStore
import com.mondrian.puzzle.ui.theme.AccentGold
import com.mondrian.puzzle.ui.theme.GridLine
import com.mondrian.puzzle.ui.theme.InkBlack
import com.mondrian.puzzle.ui.theme.MutedText
import kotlinx.coroutines.launch

private data class OnboardPage(val title: String, val body: String)

private val PAGES = listOf(
    OnboardPage(
        title = "Welcome to Thinkly Puzzle",
        body = "A daily workout for your spatial thinking. Fit every block into the frame, no gaps, no overlaps."
    ),
    OnboardPage(
        title = "Drag pieces onto the board",
        body = "Press and drag any piece from the tray onto the board. As you drag, the landing spot glows green when it fits, red when it doesn't."
    ),
    OnboardPage(
        title = "Double-tap to rotate",
        body = "Double-tap a piece — in the tray or already on the board — to spin it 90°. You can also drag a placed piece to move it elsewhere."
    ),
    OnboardPage(
        title = "88 levels, easy to hard",
        body = "Three dark blocks are already fixed in place on every level. Fill the rest with all 8 remaining pieces to solve it and unlock the next."
    ),
    OnboardPage(
        title = "We'll track your thinking",
        body = "Thinkly quietly times your solves and counts your attempts, then shows you how your speed and efficiency compare — so you can watch your spatial thinking improve."
    ),
)

@Composable
fun OnboardingScreen(onFinished: () -> Unit) {
    val context = LocalContext.current
    val pagerState = rememberPagerState(pageCount = { PAGES.size })
    val scope = rememberCoroutineScope()

    Column(
        modifier = Modifier.fillMaxSize().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Image(
            painter = painterResource(id = R.drawable.logo_thinkly),
            contentDescription = "Thinkly",
            modifier = Modifier.height(36.dp).padding(top = 16.dp, bottom = 8.dp)
        )

        HorizontalPager(
            state = pagerState,
            modifier = Modifier.weight(1f).fillMaxWidth()
        ) { page ->
            val p = PAGES[page]
            Column(
                modifier = Modifier.fillMaxSize().padding(top = 32.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Text(
                    text = p.title,
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = InkBlack,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(horizontal = 12.dp)
                )
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = p.body,
                    style = MaterialTheme.typography.bodyLarge,
                    color = MutedText,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(horizontal = 12.dp)
                )
            }
        }

        Row(
            horizontalArrangement = Arrangement.Center,
            modifier = Modifier.padding(vertical = 16.dp)
        ) {
            repeat(PAGES.size) { i ->
                val active = i == pagerState.currentPage
                Box(
                    modifier = Modifier
                        .padding(horizontal = 4.dp)
                        .size(if (active) 10.dp else 8.dp)
                        .clip(CircleShape)
                        .background(if (active) AccentGold else GridLine)
                )
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            TextButton(onClick = {
                OnboardingStore.markSeen(context)
                onFinished()
            }) {
                Text("Skip", color = MutedText)
            }
            Button(onClick = {
                if (pagerState.currentPage < PAGES.size - 1) {
                    scope.launch { pagerState.animateScrollToPage(pagerState.currentPage + 1) }
                } else {
                    OnboardingStore.markSeen(context)
                    onFinished()
                }
            }) {
                Text(if (pagerState.currentPage < PAGES.size - 1) "Next" else "Get started")
            }
        }
    }
}
