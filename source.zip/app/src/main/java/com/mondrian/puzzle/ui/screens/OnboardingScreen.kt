@file:OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)

package com.mondrian.puzzle.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.mondrian.puzzle.R
import com.mondrian.puzzle.data.OnboardingStore
import com.mondrian.puzzle.ui.theme.AccentGold
import com.mondrian.puzzle.ui.theme.CardSurface
import com.mondrian.puzzle.ui.theme.GridLine
import com.mondrian.puzzle.ui.theme.InkBlack
import com.mondrian.puzzle.ui.theme.MutedText
import com.mondrian.puzzle.ui.theme.ThinklyButton
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

private data class OnboardPage(val title: String, val body: String, val interactive: Boolean = false)

private val PAGES = listOf(
    OnboardPage(
        title = "Welcome to Thinkly Puzzle",
        body = "A daily workout for your spatial thinking. Fit every block into the frame, no gaps, no overlaps."
    ),
    OnboardPage(
        title = "Try it: drag the block onto the board",
        body = "Press and drag the block below into the empty frame. Any open spot works. Drag a placed block off the board and it snaps back to where it was.",
        interactive = true
    ),
    OnboardPage(
        title = "Try it: double-tap to rotate",
        body = "Double-tap the block on the board to spin it 90\u00b0.",
        interactive = true
    ),
    OnboardPage(
        title = "Try it: drag to the return zone",
        body = "Changed your mind about a placed block? Drag it down onto the return zone below the tray to send it back.",
        interactive = true
    ),
    OnboardPage(
        title = "88 levels, easy to hard",
        body = "Three dark blocks are already fixed in place on every level. Fill the rest with all 8 remaining pieces to solve it and unlock the next."
    ),
    OnboardPage(
        title = "We'll track your thinking",
        body = "Thinkly quietly times your solves and counts your attempts, then shows you how your speed and efficiency compare \u2014 so you can watch your spatial thinking improve."
    ),
)

@Composable
fun OnboardingScreen(onFinished: () -> Unit) {
    val context = LocalContext.current
    val pagerState = rememberPagerState(pageCount = { PAGES.size })
    val scope = rememberCoroutineScope()

    var dragDemoDone by remember { mutableStateOf(false) }
    var rotateDemoDone by remember { mutableStateOf(false) }
    var returnZoneDemoDone by remember { mutableStateOf(false) }

    val currentPage = PAGES[pagerState.currentPage]
    val canAdvance = when {
        currentPage.interactive && pagerState.currentPage == 1 -> dragDemoDone
        currentPage.interactive && pagerState.currentPage == 2 -> rotateDemoDone
        currentPage.interactive && pagerState.currentPage == 3 -> returnZoneDemoDone
        else -> true
    }

    fun goNext() {
        if (pagerState.currentPage < PAGES.size - 1) {
            scope.launch { pagerState.animateScrollToPage(pagerState.currentPage + 1) }
        } else {
            OnboardingStore.markSeen(context)
            onFinished()
        }
    }

    Column(
        modifier = Modifier.fillMaxSize().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Image(
            painter = painterResource(id = R.drawable.logo_thinkly),
            contentDescription = "Thinkly",
            modifier = Modifier.height(64.dp).padding(top = 8.dp, bottom = 4.dp)
        )

        HorizontalPager(
            state = pagerState,
            userScrollEnabled = false, // advance only via completing steps / Next, so nobody skips the "try it" gesture
            modifier = Modifier.weight(1f).fillMaxWidth()
        ) { page ->
            val p = PAGES[page]
            Column(
                modifier = Modifier.fillMaxSize().padding(top = 20.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Top
            ) {
                Text(
                    text = p.title,
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold,
                    color = InkBlack,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(horizontal = 12.dp)
                )
                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    text = p.body,
                    style = MaterialTheme.typography.bodyLarge,
                    color = MutedText,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(horizontal = 12.dp)
                )
                Spacer(modifier = Modifier.height(20.dp))

                when (page) {
                    1 -> MiniDragDemo(
                        done = dragDemoDone,
                        onDone = {
                            dragDemoDone = true
                            scope.launch {
                                delay(650)
                                pagerState.animateScrollToPage(2)
                            }
                        }
                    )
                    2 -> MiniRotateDemo(
                        done = rotateDemoDone,
                        onDone = {
                            rotateDemoDone = true
                            scope.launch {
                                delay(650)
                                pagerState.animateScrollToPage(3)
                            }
                        }
                    )
                    3 -> MiniReturnZoneDemo(
                        done = returnZoneDemoDone,
                        onDone = {
                            returnZoneDemoDone = true
                            scope.launch {
                                delay(650)
                                pagerState.animateScrollToPage(4)
                            }
                        }
                    )
                }
            }
        }

        Row(
            horizontalArrangement = Arrangement.Center,
            modifier = Modifier.padding(vertical = 16.dp)
        ) {
            repeat(PAGES.size) { i ->
                val active = i == pagerState.currentPage
                Box(
                    modifier = Modifier
                        .padding(horizontal = 4.dp)
                        .size(if (active) 10.dp else 8.dp)
                        .clip(CircleShape)
                        .background(if (active) AccentGold else GridLine)
                )
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                "Skip",
                color = MutedText,
                fontWeight = FontWeight.Medium,
                modifier = Modifier
                    .padding(12.dp)
                    .pointerInput(Unit) {
                        detectTapGestures(onTap = {
                            OnboardingStore.markSeen(context)
                            onFinished()
                        })
                    }
            )
            ThinklyButton(
                text = when {
                    !canAdvance -> "Try it above"
                    pagerState.currentPage < PAGES.size - 1 -> "Next"
                    else -> "Get started"
                },
                onClick = { goNext() },
                enabled = canAdvance
            )
        }
    }
}

/** Tiny self-contained drag demo: one draggable square, one 3x3 frame.
 * Dropping the square anywhere inside the frame counts as success. */
@Composable
private fun MiniDragDemo(done: Boolean, onDone: () -> Unit) {
    val gridSize = 3
    val cellDp = 44.dp
    var dragOffset by remember { mutableStateOf(Offset.Zero) }
    var dragging by remember { mutableStateOf(false) }
    var placed by remember { mutableStateOf(done) }

    Box(contentAlignment = Alignment.Center) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            // frame
            Box(
                modifier = Modifier
                    .size(cellDp * gridSize)
                    .clip(RoundedCornerShape(10.dp))
                    .background(CardSurface)
                    .padding(4.dp)
            ) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    for (i in 0..gridSize) {
                        drawLine(GridLine, Offset(i * size.width / gridSize, 0f), Offset(i * size.width / gridSize, size.height), strokeWidth = 2f)
                        drawLine(GridLine, Offset(0f, i * size.height / gridSize), Offset(size.width, i * size.height / gridSize), strokeWidth = 2f)
                    }
                    if (placed) {
                        val cs = size.width / gridSize
                        drawRoundRect(
                            color = Color(0xFF8FB7E8),
                            topLeft = Offset(cs, cs),
                            size = Size(cs, cs),
                            cornerRadius = CornerRadius(6f, 6f)
                        )
                    }
                }
            }
            Spacer(modifier = Modifier.height(20.dp))
            if (!placed) {
                Box(
                    modifier = Modifier
                        .size(cellDp * 0.8f)
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0xFF8FB7E8))
                        .pointerInput(Unit) {
                            detectDragGestures(
                                onDragStart = { dragging = true; dragOffset = Offset.Zero },
                                onDrag = { change, amount ->
                                    dragOffset += amount
                                    change.consume()
                                },
                                onDragEnd = {
                                    dragging = false
                                    // if dragged upward far enough to roughly reach the frame, count as success
                                    if (dragOffset.y < -60f) {
                                        placed = true
                                        onDone()
                                    } else {
                                        dragOffset = Offset.Zero
                                    }
                                },
                                onDragCancel = { dragging = false; dragOffset = Offset.Zero }
                            )
                        }
                )
            } else {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.Check, contentDescription = null, tint = Color(0xFF6FAF7C))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Nice!", color = Color(0xFF6FAF7C), fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

/** Tiny self-contained rotate demo: a 1x2 rectangle already on a mini board;
 * double-tapping it counts as success. */
@Composable
private fun MiniRotateDemo(done: Boolean, onDone: () -> Unit) {
    var rotated by remember { mutableStateOf(done) }
    val cellDp = 44.dp

    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            modifier = Modifier
                .size(cellDp * 3)
                .clip(RoundedCornerShape(10.dp))
                .background(CardSurface)
                .padding(4.dp)
        ) {
            Canvas(
                modifier = Modifier
                    .fillMaxSize()
                    .pointerInput(rotated) {
                        detectTapGestures(onDoubleTap = {
                            if (!rotated) {
                                rotated = true
                                onDone()
                            }
                        })
                    }
            ) {
                val gridSize = 3
                for (i in 0..gridSize) {
                    drawLine(GridLine, Offset(i * size.width / gridSize, 0f), Offset(i * size.width / gridSize, size.height), strokeWidth = 2f)
                    drawLine(GridLine, Offset(0f, i * size.height / gridSize), Offset(size.width, i * size.height / gridSize), strokeWidth = 2f)
                }
                val cs = size.width / gridSize
                val w = if (rotated) 1 else 2
                val h = if (rotated) 2 else 1
                drawRoundRect(
                    color = Color(0xFFF29B9B),
                    topLeft = Offset(cs * 0.5f, cs),
                    size = Size(cs * w, cs * h),
                    cornerRadius = CornerRadius(6f, 6f)
                )
            }
        }
        Spacer(modifier = Modifier.height(16.dp))
        if (rotated) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.Check, contentDescription = null, tint = Color(0xFF6FAF7C))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Rotated!", color = Color(0xFF6FAF7C), fontWeight = FontWeight.Bold)
            }
        } else {
            Text("Double-tap the block above", color = MutedText, style = MaterialTheme.typography.bodyMedium)
        }
    }
}

/** Tiny self-contained "return zone" demo: a block already on a mini board;
 * dragging it down onto the return-zone box below sends it back. */
@Composable
private fun MiniReturnZoneDemo(done: Boolean, onDone: () -> Unit) {
    var sentBack by remember { mutableStateOf(done) }
    var dragOffset by remember { mutableStateOf(Offset.Zero) }
    var dragging by remember { mutableStateOf(false) }
    val cellDp = 44.dp

    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            modifier = Modifier
                .size(cellDp * 3)
                .clip(RoundedCornerShape(10.dp))
                .background(CardSurface)
                .padding(4.dp)
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val gridSize = 3
                for (i in 0..gridSize) {
                    drawLine(GridLine, Offset(i * size.width / gridSize, 0f), Offset(i * size.width / gridSize, size.height), strokeWidth = 2f)
                    drawLine(GridLine, Offset(0f, i * size.height / gridSize), Offset(size.width, i * size.height / gridSize), strokeWidth = 2f)
                }
                if (!sentBack) {
                    val cs = size.width / gridSize
                    drawRoundRect(
                        color = Color(0xFFF29B9B),
                        topLeft = Offset(cs, cs) + dragOffset,
                        size = Size(cs, cs),
                        cornerRadius = CornerRadius(6f, 6f)
                    )
                }
            }
        }
        Spacer(modifier = Modifier.height(14.dp))
        if (sentBack) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.Check, contentDescription = null, tint = Color(0xFF6FAF7C))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Sent back!", color = Color(0xFF6FAF7C), fontWeight = FontWeight.Bold)
            }
        } else {
            Box(
                modifier = Modifier
                    .size(cellDp * 3, 40.dp)
                    .clip(RoundedCornerShape(10.dp))
                    .background(if (dragging) Color(0xFFD6605A).copy(alpha = 0.18f) else MutedText.copy(alpha = 0.10f))
                    .pointerInput(Unit) {
                        detectDragGestures(
                            onDragStart = { dragging = true },
                            onDrag = { change, amount ->
                                dragOffset += amount
                                change.consume()
                            },
                            onDragEnd = {
                                dragging = false
                                if (dragOffset.y > 40f) {
                                    sentBack = true
                                    onDone()
                                } else {
                                    dragOffset = Offset.Zero
                                }
                            },
                            onDragCancel = { dragging = false; dragOffset = Offset.Zero }
                        )
                    },
                contentAlignment = Alignment.Center
            ) {
                Text(
                    "Return zone",
                    color = MutedText,
                    style = MaterialTheme.typography.bodyMedium,
                    textAlign = TextAlign.Center
                )
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text("Drag the block down into the box above", color = MutedText, style = MaterialTheme.typography.bodyMedium, textAlign = TextAlign.Center)
        }
    }
}
