package com.mondrian.puzzle.data

import android.content.Context
import kotlin.math.roundToInt

data class CognitiveSkill(
    val name: String,
    val score: Int, // 0-100, a gamified estimate, not a clinical measurement
    val description: String
)

/** Turns real play data (attempts, hints, speed, consistency, streak) into a
 * friendly "which skills is this exercising" breakdown. This is intentionally
 * framed as a motivational estimate, not a scientific or medical assessment --
 * we have no way to actually measure brain activity, only play patterns. */
object CognitiveReport {

    fun compute(context: Context): List<CognitiveSkill> {
        val solves = AnalyticsStore.getAllSolves(context)
        if (solves.size < 3) return emptyList() // not enough data for a meaningful read yet

        val avgAttempts = solves.map { it.attempts }.average()
        val firstTryRate = solves.count { it.attempts == 1 }.toDouble() / solves.size
        val noHintRate = solves.count { it.hintsUsed == 0 }.toDouble() / solves.size
        val hardSolves = solves.count { it.difficulty == "hard" }
        val longestStreak = StreakStore.getLongestStreak(context)

        val sorted = solves.sortedBy { it.timestamp }
        val improvementPct = if (sorted.size >= 6) {
            val firstFew = sorted.take(3).map { it.timeMs.toDouble() }.average()
            val lastFew = sorted.takeLast(3).map { it.timeMs.toDouble() }.average()
            if (firstFew > 0) ((firstFew - lastFew) / firstFew * 100) else 0.0
        } else 0.0

        // Spatial reasoning: fewer attempts needed to fit pieces together correctly
        val spatial = (100 - (avgAttempts - 1) * 22).coerceIn(15.0, 97.0).roundToInt()

        // Logical planning: solving cleanly (first try, no hints) reflects thinking ahead
        val planning = (firstTryRate * 55 + noHintRate * 45).coerceIn(15.0, 97.0).roundToInt()

        // Persistence: sticking with it across a long streak and into harder levels
        val persistence = (minOf(longestStreak, 30) * 2.0 + minOf(hardSolves, 20) * 2.5)
            .coerceIn(15.0, 97.0).roundToInt()

        // Adaptability: measurably getting faster with practice
        val adaptability = (55 + improvementPct * 0.9).coerceIn(15.0, 97.0).roundToInt()

        return listOf(
            CognitiveSkill(
                "Spatial reasoning", spatial,
                "Visualizing how shapes fit together and rotate in space \u2014 exercised every time you place or rotate a block."
            ),
            CognitiveSkill(
                "Logical planning", planning,
                "Thinking several moves ahead before committing \u2014 reflected in solving with fewer attempts and hints."
            ),
            CognitiveSkill(
                "Persistence", persistence,
                "Sticking with a hard problem over time \u2014 built by your play streak and steady progress into harder levels."
            ),
            CognitiveSkill(
                "Adaptability", adaptability,
                "Learning from earlier attempts and getting faster with practice."
            )
        )
    }
}
