package com.mondrian.puzzle.ui.screens

import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.Animatable
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInWindow
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.mondrian.puzzle.data.FIXED_BLOCK_COLOR
import com.mondrian.puzzle.data.PIECE_COLORS
import com.mondrian.puzzle.data.PlacedPiece
import com.mondrian.puzzle.data.SoundPlayer
import com.mondrian.puzzle.ui.theme.GridLine
import com.mondrian.puzzle.ui.theme.Paper
import com.mondrian.puzzle.viewmodel.GameViewModel
import kotlin.math.floor
import kotlinx.coroutines.CancellationException

private fun safeHaptic(haptic: androidx.compose.ui.hapticfeedback.HapticFeedback) {
    try {
        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
    } catch (_: Throwable) {
        // Haptics are a nice-to-have; if the platform throws here for any reason
        // (e.g. an edge case around the window losing focus), we must not let it
        // kill the long-lived gesture-detection coroutine that called us -- that
        // would silently break all future taps/drags on the board until restart.
    }
}

@Composable
fun BoardView(
    vm: GameViewModel,
    onGeomChanged: (BoardGeom) -> Unit,
    returnZoneRect: Rect?,
    modifier: Modifier = Modifier
) {
    val engine = vm.engine ?: return
    val boardSize = engine.boardSize
    @Suppress("UNUSED_VARIABLE") val boardVersion = vm.boardVersion
    val dragState = vm.dragState

    var geom by remember { androidx.compose.runtime.mutableStateOf<BoardGeom?>(null) }
    val density = LocalDensity.current
    val haptic = LocalHapticFeedback.current
    // Same fix as the earlier boardGeom bug: the drag gesture below is set up once
    // (keyed on currentLevel) and would otherwise permanently see whatever
    // returnZoneRect was at that first moment -- null, since the return zone
    // hasn't finished laying itself out yet. This keeps it live.
    val latestReturnZoneRect by rememberUpdatedState(returnZoneRect)

    Box(
        modifier = modifier
            .fillMaxWidth()
            .aspectRatio(1f)
    ) {
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .onGloballyPositioned { coords ->
                    val cellPx = coords.size.width.toFloat() / boardSize
                    val g = BoardGeom(coords.positionInWindow(), cellPx)
                    geom = g
                    onGeomChanged(g)
                }
                .pointerInput(vm.currentLevel) {
                    // Self-healing: detectTapGestures runs forever under normal
                    // operation. If anything inside ever throws (we've chased a
                    // few different causes of this across builds and want a
                    // backstop regardless of the exact trigger), this restarts
                    // detection immediately instead of leaving taps dead until
                    // the user force-quits the app.
                    while (true) {
                        try {
                            detectTapGestures(
                                onDoubleTap = { offset ->
                                    val cellPx = size.width.toFloat() / boardSize
                                    val gx = floor(offset.x / cellPx).toInt().coerceIn(0, boardSize - 1)
                                    val gy = floor(offset.y / cellPx).toInt().coerceIn(0, boardSize - 1)
                                    val piece = engine.pieceAt(gx, gy)
                                    if (piece != null) {
                                        vm.rotatePlacedInPlace(piece.piece.id)
                                        safeHaptic(haptic)
                                        SoundPlayer.playTick()
                                    }
                                }
                            )
                        } catch (e: CancellationException) {
                            // Not an error -- this is coroutines' normal signal that
                            // this gesture scope is being torn down (screen leaving,
                            // recomposition restarting it, etc). MUST propagate, never
                            // swallow: catching this and looping again is what caused
                            // the hang/crash-after-one-drag bug -- an already-cancelled
                            // scope throws again on every subsequent suspend call, so
                            // swallowing it here spun a tight infinite loop with no
                            // chance to actually yield.
                            throw e
                        } catch (_: Throwable) {
                            // fall through and restart the loop
                        }
                    }
                }
                .pointerInput(vm.currentLevel) {
                    while (true) {
                        try {
                            detectDragGestures(
                                onDragStart = { offset ->
                                    val cellPx = size.width.toFloat() / boardSize
                                    val gx = floor(offset.x / cellPx).toInt().coerceIn(0, boardSize - 1)
                                    val gy = floor(offset.y / cellPx).toInt().coerceIn(0, boardSize - 1)
                                    val piece = engine.pieceAt(gx, gy)
                                    if (piece != null) {
                                        val g = geom ?: return@detectDragGestures
                                        val fingerInWindow = g.topLeftInWindow + offset
                                        vm.startDragFromBoard(piece.piece.id, fingerInWindow)
                                        safeHaptic(haptic)
                                        SoundPlayer.playTick()
                                    }
                                },
                                onDrag = { change, _ ->
                                    change.consume()
                                    if (vm.dragState != null) {
                                        val g = geom
                                        if (g != null) vm.updateDrag(g.topLeftInWindow + change.position)
                                    }
                                },
                                onDragEnd = {
                                    val ds = vm.dragState
                                    val g = geom
                                    if (ds != null && g != null) {
                                        val overReturnZone = latestReturnZoneRect?.contains(ds.fingerPosInWindow) == true
                                        val outcome = if (overReturnZone && ds.fromBoard) {
                                            vm.endDrag(null, null, sendToTray = true)
                                        } else {
                                            val piece = engine.pieces.firstOrNull { it.piece.id == ds.pieceId }
                                            if (piece != null) {
                                                val wPx = piece.piece.width(ds.rotated) * g.cellPx
                                                val hPx = piece.piece.height(ds.rotated) * g.cellPx
                                                val target = computeTargetCell(ds, g, boardSize, wPx, hPx)
                                                vm.endDrag(target?.first, target?.second)
                                            } else {
                                                vm.cancelDrag()
                                                false
                                            }
                                        }
                                        if (outcome) {
                                            safeHaptic(haptic)
                                            SoundPlayer.playPlace()
                                        }
                                    } else {
                                        vm.cancelDrag()
                                    }
                                },
                                onDragCancel = { vm.cancelDrag() }
                            )
                        } catch (e: CancellationException) {
                            throw e // see note above -- must always propagate
                        } catch (_: Throwable) {
                            // fall through and restart the loop; also make sure
                            // we don't leave a piece permanently "picked up" if
                            // the exception happened mid-drag
                            try { vm.cancelDrag() } catch (_: Throwable) {}
                        }
                    }
                }
        ) {
            drawRect(Paper, size = this.size)
            val cell = this.size.width / boardSize
            val gap = cell * 0.045f
            val radius = CornerRadius(cell * 0.16f, cell * 0.16f)

            // faint backdrops for every empty cell (subtle grid feel, Almanac-like separated tiles)
            for (yy in 0 until boardSize) {
                for (xx in 0 until boardSize) {
                    if (!engine.isFixedAt(xx, yy) && engine.pieceAt(xx, yy) == null) {
                        drawRoundedBlock(xx, yy, 1, 1, cell, gap, radius, GridLine.copy(alpha = 0.35f))
                    }
                }
            }

            // fixed obstacle blocks
            for (b in engine.level.fixedBlocks) {
                drawRoundedBlock(b.x, b.y, b.w, b.h, cell, gap, radius, Color(FIXED_BLOCK_COLOR))
            }

            // live snap preview while dragging
            val g = geom
            if (dragState != null && g != null) {
                val draggedPiece = engine.pieces.firstOrNull { it.piece.id == dragState.pieceId }
                if (draggedPiece != null) {
                    val w = draggedPiece.piece.width(dragState.rotated)
                    val h = draggedPiece.piece.height(dragState.rotated)
                    val target = computeTargetCell(dragState, g, boardSize, w * g.cellPx, h * g.cellPx)
                    if (target != null) {
                        val valid = engine.canPlace(draggedPiece, target.first, target.second, dragState.rotated)
                        val tint = if (valid) Color(0xFF6FAF7C).copy(alpha = 0.55f) else Color(0xFFD6605A).copy(alpha = 0.55f)
                        drawRoundedBlock(target.first, target.second, w, h, cell, gap, radius, tint)
                    }
                }
            }
        }

        // placed movable pieces rendered as real composables (not Canvas draws) so they
        // can smoothly animate into position and pop when placed, instead of snapping.
        val gCellPx = geom?.cellPx
        if (gCellPx != null) {
            val cellDp = with(density) { gCellPx.toDp() }
            for (p in engine.pieces.filter { it.placed }) {
                key(p.piece.id) {
                    val color = Color(PIECE_COLORS[(p.piece.id - 1) % PIECE_COLORS.size])
                    val isCorrect = vm.showCorrectHighlight && engine.isCorrectlyPlaced(p)
                    AnimatedPieceBlock(piece = p, cellDp = cellDp, color = color, highlightCorrect = isCorrect)
                }
            }
        }
    }
}

@Composable
private fun AnimatedPieceBlock(piece: PlacedPiece, cellDp: Dp, color: Color, highlightCorrect: Boolean) {
    val w = piece.piece.width(piece.rotated)
    val h = piece.piece.height(piece.rotated)
    val targetX = cellDp * piece.x
    val targetY = cellDp * piece.y
    val fullWidth = cellDp * w
    val fullHeight = cellDp * h

    val animX by animateDpAsState(
        targetValue = targetX,
        animationSpec = spring(dampingRatio = Spring.DampingRatioLowBouncy, stiffness = Spring.StiffnessMedium),
        label = "pieceX"
    )
    val animY by animateDpAsState(
        targetValue = targetY,
        animationSpec = spring(dampingRatio = Spring.DampingRatioLowBouncy, stiffness = Spring.StiffnessMedium),
        label = "pieceY"
    )

    // "Pop" feedback whenever a piece (re)lands: animate its size in from
    // slightly-smaller to full size with a bouncy spring, instead of a
    // graphicsLayer scale transform (kept simple, no extra APIs needed).
    val sizeFraction = remember(piece.piece.id) { Animatable(0.85f) }
    LaunchedEffect(piece.piece.id, piece.x, piece.y) {
        sizeFraction.snapTo(0.85f)
        sizeFraction.animateTo(1f, animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy))
    }

    val gapDp = cellDp * 0.045f
    val radiusDp = cellDp * 0.16f
    val animatedWidth = fullWidth * sizeFraction.value
    val animatedHeight = fullHeight * sizeFraction.value
    val centerOffsetX = (fullWidth - animatedWidth) / 2f
    val centerOffsetY = (fullHeight - animatedHeight) / 2f

    Box(
        modifier = Modifier
            .offset(x = animX + centerOffsetX, y = animY + centerOffsetY)
            .size(animatedWidth, animatedHeight)
            .padding(gapDp)
            .clip(RoundedCornerShape(radiusDp))
            .background(color)
    ) {
        if (highlightCorrect) {
            Box(
                modifier = Modifier
                    .matchParentSize()
                    .clip(RoundedCornerShape(radiusDp))
                    .background(Color(0xFF6FAF7C).copy(alpha = 0.38f))
                    .border(2.dp, Color(0xFF3E8E52), RoundedCornerShape(radiusDp))
            )
        }
    }
}

private fun DrawScope.drawRoundedBlock(
    x: Int, y: Int, w: Int, h: Int, cell: Float, gap: Float, radius: CornerRadius, color: Color
) {
    drawRoundRect(
        color = color,
        topLeft = Offset(x * cell + gap, y * cell + gap),
        size = Size(w * cell - gap * 2, h * cell - gap * 2),
        cornerRadius = radius
    )
}
