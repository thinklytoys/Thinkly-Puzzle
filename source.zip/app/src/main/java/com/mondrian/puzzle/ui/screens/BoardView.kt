package com.mondrian.puzzle.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInWindow
import com.mondrian.puzzle.data.FIXED_BLOCK_COLOR
import com.mondrian.puzzle.data.PIECE_COLORS
import com.mondrian.puzzle.ui.theme.GridLine
import com.mondrian.puzzle.ui.theme.Paper
import com.mondrian.puzzle.viewmodel.GameViewModel
import kotlin.math.floor

@Composable
fun BoardView(
    vm: GameViewModel,
    onGeomChanged: (BoardGeom) -> Unit,
    modifier: Modifier = Modifier
) {
    val engine = vm.engine ?: return
    val boardSize = engine.boardSize
    @Suppress("UNUSED_VARIABLE") val boardVersion = vm.boardVersion
    val dragState = vm.dragState

    var geom by androidx.compose.runtime.remember { androidx.compose.runtime.mutableStateOf<BoardGeom?>(null) }

    Canvas(
        modifier = modifier
            .fillMaxWidth()
            .aspectRatio(1f)
            .onGloballyPositioned { coords ->
                val cellPx = coords.size.width.toFloat() / boardSize
                val g = BoardGeom(coords.positionInWindow(), cellPx)
                geom = g
                onGeomChanged(g)
            }
            .pointerInput(vm.currentLevel) {
                detectTapGestures(
                    onDoubleTap = { offset ->
                        val cellPx = size.width.toFloat() / boardSize
                        val gx = floor(offset.x / cellPx).toInt().coerceIn(0, boardSize - 1)
                        val gy = floor(offset.y / cellPx).toInt().coerceIn(0, boardSize - 1)
                        val piece = engine.pieceAt(gx, gy)
                        if (piece != null) vm.rotatePlacedInPlace(piece.piece.id)
                    }
                )
            }
            .pointerInput(vm.currentLevel) {
                detectDragGestures(
                    onDragStart = { offset ->
                        val cellPx = size.width.toFloat() / boardSize
                        val gx = floor(offset.x / cellPx).toInt().coerceIn(0, boardSize - 1)
                        val gy = floor(offset.y / cellPx).toInt().coerceIn(0, boardSize - 1)
                        val piece = engine.pieceAt(gx, gy)
                        if (piece != null) {
                            val g = geom ?: return@detectDragGestures
                            val fingerInWindow = g.topLeftInWindow + offset
                            vm.startDragFromBoard(piece.piece.id, fingerInWindow)
                        }
                    },
                    onDrag = { change, _ ->
                        change.consume()
                        if (vm.dragState != null) {
                            val g = geom
                            if (g != null) vm.updateDrag(g.topLeftInWindow + change.position)
                        }
                    },
                    onDragEnd = {
                        val ds = vm.dragState
                        val g = geom
                        if (ds != null && g != null) {
                            val piece = engine.pieces.first { it.piece.id == ds.pieceId }
                            val wPx = piece.piece.width(ds.rotated) * g.cellPx
                            val hPx = piece.piece.height(ds.rotated) * g.cellPx
                            val target = computeTargetCell(ds, g, boardSize, wPx, hPx)
                            vm.endDrag(target?.first, target?.second)
                        } else {
                            vm.cancelDrag()
                        }
                    },
                    onDragCancel = { vm.cancelDrag() }
                )
            }
    ) {
        drawRect(Paper, size = this.size)
        val cell = this.size.width / boardSize
        val gap = cell * 0.045f
        val radius = CornerRadius(cell * 0.16f, cell * 0.16f)

        // faint backdrops for every cell (subtle grid feel, Almanac-like separated tiles)
        for (yy in 0 until boardSize) {
            for (xx in 0 until boardSize) {
                if (!engine.isFixedAt(xx, yy) && engine.pieceAt(xx, yy) == null) {
                    drawRoundedBlock(xx, yy, 1, 1, cell, gap, radius, GridLine.copy(alpha = 0.35f))
                }
            }
        }

        // fixed obstacle blocks
        for (b in engine.level.fixedBlocks) {
            drawRoundedBlock(b.x, b.y, b.w, b.h, cell, gap, radius, Color(FIXED_BLOCK_COLOR))
        }

        // placed movable pieces
        for (p in engine.pieces.filter { it.placed }) {
            val color = Color(PIECE_COLORS[(p.piece.id - 1) % PIECE_COLORS.size])
            val w = p.piece.width(p.rotated)
            val h = p.piece.height(p.rotated)
            drawRoundedBlock(p.x, p.y, w, h, cell, gap, radius, color)
        }

        // live snap preview while dragging
        val g = geom
        if (dragState != null && g != null) {
            val draggedPiece = engine.pieces.first { it.piece.id == dragState.pieceId }
            val w = draggedPiece.piece.width(dragState.rotated)
            val h = draggedPiece.piece.height(dragState.rotated)
            val target = computeTargetCell(dragState, g, boardSize, w * g.cellPx, h * g.cellPx)
            if (target != null) {
                val valid = engine.canPlace(draggedPiece, target.first, target.second, dragState.rotated)
                val tint = if (valid) Color(0xFF6FAF7C).copy(alpha = 0.55f) else Color(0xFFD6605A).copy(alpha = 0.55f)
                drawRoundedBlock(target.first, target.second, w, h, cell, gap, radius, tint)
            }
        }
    }
}

private fun DrawScope.drawRoundedBlock(
    x: Int, y: Int, w: Int, h: Int, cell: Float, gap: Float, radius: CornerRadius, color: Color
) {
    drawRoundRect(
        color = color,
        topLeft = Offset(x * cell + gap, y * cell + gap),
        size = Size(w * cell - gap * 2, h * cell - gap * 2),
        cornerRadius = radius
    )
}
