package com.mondrian.puzzle.data

import android.content.Context

object OnboardingStore {
    private const val PREFS = "mondrian_onboarding"
    private const val KEY_SEEN = "has_seen_onboarding"

    fun hasSeenOnboarding(context: Context): Boolean {
        return context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getBoolean(KEY_SEEN, false)
    }

    fun markSeen(context: Context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean(KEY_SEEN, true).apply()
    }
}
