package com.mondrian.puzzle.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInWindow
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.mondrian.puzzle.data.PIECE_COLORS
import com.mondrian.puzzle.ui.theme.AccentGold
import com.mondrian.puzzle.ui.theme.CardSurface
import com.mondrian.puzzle.ui.theme.InkBlack
import com.mondrian.puzzle.ui.theme.MutedText
import com.mondrian.puzzle.ui.theme.Paper
import com.mondrian.puzzle.ui.theme.ThinklyButton
import com.mondrian.puzzle.ui.theme.ThinklyChip
import com.mondrian.puzzle.ui.theme.ThinklyHeader
import com.mondrian.puzzle.ui.theme.ThinklyIconButton
import com.mondrian.puzzle.viewmodel.GameViewModel

@Composable
fun GameScreen(
    levelNumber: Int,
    vm: GameViewModel,
    onBack: () -> Unit,
    onNextLevel: (Int) -> Unit
) {
    LaunchedEffect(levelNumber) {
        vm.loadLevel(levelNumber)
    }
    val engine = vm.engine
    // Reading boardVersion here ties GameScreen's recomposition (and therefore the
    // piece tray and win-check) to every placement/rotation/reset mutation, even
    // ones that don't otherwise change dragState.
    @Suppress("UNUSED_VARIABLE") val boardVersionTick = vm.boardVersion

    var rootOriginInWindow by remember { mutableStateOf(Offset.Zero) }
    var boardGeom by remember { mutableStateOf<BoardGeom?>(null) }

    Column(modifier = Modifier.fillMaxSize().background(Paper)) {
        ThinklyHeader(
            modifier = Modifier.fillMaxWidth(),
            navigationIcon = {
                ThinklyIconButton(Icons.AutoMirrored.Filled.ArrowBack, "Back", onClick = onBack)
            },
            title = {
                Text(
                    "Level $levelNumber",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = InkBlack
                )
            },
            actions = {
                ThinklyIconButton(Icons.Filled.Refresh, "Reset", onClick = { vm.resetLevel() })
            }
        )

        if (engine == null) return@Column

        Box(modifier = Modifier.fillMaxSize()) {
            val ds = vm.dragState

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                BoardView(
                    vm = vm,
                    onGeomChanged = { boardGeom = it },
                    modifier = Modifier.fillMaxWidth()
                )

                Text(
                    text = "Drag a piece onto the board \u00b7 double-tap to rotate",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MutedText,
                    modifier = Modifier.padding(vertical = 10.dp)
                )

                PieceTray(
                    vm = vm,
                    pieces = vm.unplacedPieces(),
                    boardGeom = boardGeom,
                    boardSize = engine.boardSize,
                    modifier = Modifier.fillMaxWidth().weight(1f, fill = false)
                )
            }

            // floating ghost of the piece currently being dragged
            if (ds != null && boardGeom != null) {
                val piece = engine.pieces.first { it.piece.id == ds.pieceId }
                val w = piece.piece.width(ds.rotated)
                val h = piece.piece.height(ds.rotated)
                val cellPx = boardGeom!!.cellPx
                val wPx = w * cellPx
                val hPx = h * cellPx
                val topLeftInWindow = ds.fingerPosInWindow - Offset(wPx / 2f, hPx / 2f)
                val localOffset = topLeftInWindow - rootOriginInWindow
                val density = androidx.compose.ui.platform.LocalDensity.current
                val color = Color(PIECE_COLORS[(piece.piece.id - 1) % PIECE_COLORS.size])
                Box(
                    modifier = Modifier
                        .offset(
                            x = with(density) { localOffset.x.toDp() },
                            y = with(density) { localOffset.y.toDp() }
                        )
                        .size(
                            with(density) { (w * cellPx).toDp() },
                            with(density) { (h * cellPx).toDp() }
                        )
                        .clip(RoundedCornerShape(10.dp))
                        .background(color.copy(alpha = 0.9f))
                )
            }

            AnimatedVisibility(
                visible = vm.won,
                enter = fadeIn(),
                exit = fadeOut(),
                modifier = Modifier.fillMaxSize()
            ) {
                SolvedOverlay(
                    levelNumber = levelNumber,
                    timeMs = vm.lastSolveTimeMs,
                    attempts = vm.lastSolveAttempts,
                    onNext = { if (levelNumber < 88) onNextLevel(levelNumber + 1) else onBack() },
                    onLevelSelect = onBack,
                    isLastLevel = levelNumber >= 88
                )
            }
        }
    }
}

@Composable
private fun SolvedOverlay(
    levelNumber: Int,
    timeMs: Long?,
    attempts: Int?,
    onNext: () -> Unit,
    onLevelSelect: () -> Unit,
    isLastLevel: Boolean
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(InkBlack.copy(alpha = 0.45f)),
        contentAlignment = Alignment.Center
    ) {
        AnimatedVisibility(
            visible = true,
            enter = scaleIn(initialScale = 0.85f, animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy)) + fadeIn(),
            exit = scaleOut() + fadeOut()
        ) {
            Column(
                modifier = Modifier
                    .padding(32.dp)
                    .clip(RoundedCornerShape(24.dp))
                    .background(CardSurface)
                    .padding(28.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    modifier = Modifier
                        .size(64.dp)
                        .clip(RoundedCornerShape(32.dp))
                        .background(AccentGold.copy(alpha = 0.18f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Filled.Check, contentDescription = null, tint = AccentGold, modifier = Modifier.size(32.dp))
                }
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    "Solved!",
                    style = MaterialTheme.typography.headlineMedium,
                    color = InkBlack,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    "Level $levelNumber complete",
                    style = MaterialTheme.typography.bodyLarge,
                    color = MutedText
                )
                Spacer(modifier = Modifier.height(18.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    if (timeMs != null) {
                        ThinklyChip(text = formatSolveTime(timeMs), background = Paper)
                    }
                    if (attempts != null) {
                        ThinklyChip(text = "$attempts attempt${if (attempts == 1) "" else "s"}", background = Paper)
                    }
                }
                Spacer(modifier = Modifier.height(24.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    ThinklyButton(
                        text = "Level select",
                        onClick = onLevelSelect,
                        filled = false
                    )
                    ThinklyButton(
                        text = if (isLastLevel) "Done" else "Next level",
                        onClick = onNext,
                        filled = true
                    )
                }
            }
        }
    }
}

private fun formatSolveTime(ms: Long): String {
    val totalSec = ms / 1000
    val m = totalSec / 60
    val s = totalSec % 60
    return if (m > 0) "${m}m ${s}s" else "${s}s"
}
