package com.mondrian.puzzle.ui.screens

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.foundation.rememberScrollState
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInWindow
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.toSize
import com.mondrian.puzzle.data.Achievement
import com.mondrian.puzzle.data.GameEngine
import com.mondrian.puzzle.data.PIECE_COLORS
import com.mondrian.puzzle.data.ShareCardGenerator
import com.mondrian.puzzle.ui.theme.AccentGold
import com.mondrian.puzzle.ui.theme.CardSurface
import com.mondrian.puzzle.ui.theme.GridLine
import com.mondrian.puzzle.ui.theme.InkBlack
import com.mondrian.puzzle.ui.theme.MutedText
import com.mondrian.puzzle.ui.theme.Paper
import com.mondrian.puzzle.ui.theme.ThinklyButton
import com.mondrian.puzzle.ui.theme.ThinklyChip
import com.mondrian.puzzle.ui.theme.ThinklyHeader
import com.mondrian.puzzle.ui.theme.ThinklyIconButton
import com.mondrian.puzzle.viewmodel.GameViewModel
import kotlin.random.Random

@Composable
fun GameScreen(
    levelNumber: Int,
    vm: GameViewModel,
    onBack: () -> Unit,
    onNextLevel: (Int) -> Unit
) {
    LaunchedEffect(levelNumber) {
        vm.loadLevel(levelNumber)
    }
    val engine = vm.engine
    // Reading boardVersion here ties GameScreen's recomposition (and therefore the
    // piece tray and win-check) to every placement/rotation/reset mutation, even
    // ones that don't otherwise change dragState.
    @Suppress("UNUSED_VARIABLE") val boardVersionTick = vm.boardVersion

    var rootOriginInWindow by remember { mutableStateOf(Offset.Zero) }
    var boardGeom by remember { mutableStateOf<BoardGeom?>(null) }
    var returnZoneRect by remember { mutableStateOf<Rect?>(null) }
    val context = androidx.compose.ui.platform.LocalContext.current

    Column(modifier = Modifier.fillMaxSize().background(Paper)) {
        ThinklyHeader(
            modifier = Modifier.fillMaxWidth(),
            navigationIcon = {
                ThinklyIconButton(Icons.AutoMirrored.Filled.ArrowBack, "Back", onClick = onBack)
            },
            title = {
                Text(
                    "Level $levelNumber",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = InkBlack
                )
            },
            actions = {
                if (vm.isViewingSolvedSnapshot) {
                    ThinklyIconButton(
                        Icons.Filled.Share,
                        "Share",
                        onClick = {
                            val eng = vm.engine
                            val record = vm.viewedLevelSolveRecord
                            if (eng != null) {
                                ShareCardGenerator.shareSolvedLevel(
                                    context = context,
                                    levelNumber = levelNumber,
                                    engine = eng,
                                    timeMs = record?.timeMs,
                                    attempts = record?.attempts,
                                    hints = record?.hintsUsed
                                )
                            }
                        }
                    )
                }
                ThinklyIconButton(Icons.Filled.Refresh, "Reset", onClick = { vm.resetLevel() })
            }
        )

        if (engine == null) return@Column

        val haptic = androidx.compose.ui.platform.LocalHapticFeedback.current
        LaunchedEffect(vm.hintAvailable) {
            if (vm.hintAvailable) {
                try {
                    haptic.performHapticFeedback(androidx.compose.ui.hapticfeedback.HapticFeedbackType.TextHandleMove)
                } catch (_: Throwable) {
                    // non-critical; never let this break anything
                }
            }
        }

        // Status row: live timer on the left, hint button appears on the right
        // once one is available (roughly every 2 minutes of play). Hidden
        // entirely while just viewing an already-completed level (nothing is
        // being timed and hints don't apply until you hit Reset).
        if (!vm.isViewingSolvedSnapshot) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = formatTimer(vm.elapsedSeconds),
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.SemiBold,
                    color = MutedText
                )
                if (vm.hintAvailable && !vm.won) {
                    Row(
                        modifier = Modifier
                            .clip(RoundedCornerShape(50))
                            .background(AccentGold.copy(alpha = 0.18f))
                            .clickable { vm.useHint() }
                            .padding(horizontal = 14.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Filled.Lightbulb, contentDescription = null, tint = AccentGold, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Hint", color = AccentGold, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelLarge)
                    }
                }
            }
        }

        Box(
            modifier = Modifier
                .fillMaxSize()
                .onGloballyPositioned { rootOriginInWindow = it.positionInWindow() }
        ) {
            val ds = vm.dragState
            val isDraggingFromBoard = ds != null && ds.fromBoard
            val isOverReturnZone = ds != null && returnZoneRect?.contains(ds.fingerPosInWindow) == true

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                BoardView(
                    vm = vm,
                    onGeomChanged = { boardGeom = it },
                    returnZoneRect = returnZoneRect,
                    modifier = Modifier.fillMaxWidth()
                )

                Text(
                    text = "Drag onto the board \u00b7 double-tap to rotate",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MutedText,
                    modifier = Modifier.padding(vertical = 8.dp)
                )

                // Drop target sits just below the board (short drag distance),
                // above the tray -- drag a placed block up here to remove it.
                ReturnZone(
                    highlighted = isDraggingFromBoard,
                    hovering = isOverReturnZone,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 8.dp)
                        .onGloballyPositioned { coords ->
                            returnZoneRect = Rect(coords.positionInWindow(), coords.size.toSize())
                        }
                )

                PieceTray(
                    vm = vm,
                    pieces = vm.unplacedPieces(),
                    boardGeom = boardGeom,
                    boardSize = engine.boardSize,
                    modifier = Modifier.fillMaxWidth().weight(1f, fill = false)
                )
            }

            // floating ghost of the piece currently being dragged
            val ghostPiece = if (ds != null) engine.pieces.firstOrNull { it.piece.id == ds.pieceId } else null
            if (ds != null && boardGeom != null && ghostPiece != null) {
                val piece = ghostPiece
                val w = piece.piece.width(ds.rotated)
                val h = piece.piece.height(ds.rotated)
                val cellPx = boardGeom!!.cellPx
                val wPx = w * cellPx
                val hPx = h * cellPx
                val topLeftInWindow = ds.fingerPosInWindow - Offset(wPx / 2f, hPx / 2f)
                val localOffset = topLeftInWindow - rootOriginInWindow
                val density = androidx.compose.ui.platform.LocalDensity.current
                val color = Color(PIECE_COLORS[(piece.piece.id - 1) % PIECE_COLORS.size])

                // Subtle "lift" while carrying a piece -- a small, quick scale-up
                // on pickup rather than a constant static ghost.
                val liftScale by animateFloatAsState(
                    targetValue = if (isOverReturnZone) 0.85f else 1.06f,
                    animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy),
                    label = "liftScale"
                )
                val liftedW = wPx * liftScale
                val liftedH = hPx * liftScale
                val centerAdjustX = (wPx - liftedW) / 2f
                val centerAdjustY = (hPx - liftedH) / 2f

                Box(
                    modifier = Modifier
                        .offset(
                            x = with(density) { (localOffset.x + centerAdjustX).toDp() },
                            y = with(density) { (localOffset.y + centerAdjustY).toDp() }
                        )
                        .size(
                            with(density) { liftedW.toDp() },
                            with(density) { liftedH.toDp() }
                        )
                        .clip(RoundedCornerShape(10.dp))
                        .background(color.copy(alpha = if (isOverReturnZone) 0.6f else 0.92f))
                )
            }

            androidx.compose.animation.AnimatedVisibility(
                visible = vm.won,
                enter = fadeIn(),
                exit = fadeOut(),
                modifier = Modifier.fillMaxSize()
            ) {
                SolvedOverlay(
                    levelNumber = levelNumber,
                    engine = engine,
                    timeMs = vm.lastSolveTimeMs,
                    attempts = vm.lastSolveAttempts,
                    hints = vm.lastSolveHints,
                    returns = vm.lastSolveReturns,
                    newlyUnlocked = vm.newlyUnlockedAchievements,
                    onNext = { if (levelNumber < 88) onNextLevel(levelNumber + 1) else onBack() },
                    onLevelSelect = onBack,
                    isLastLevel = levelNumber >= 88
                )
            }
        }
    }
}

@Composable
private fun ReturnZone(highlighted: Boolean, hovering: Boolean, modifier: Modifier = Modifier) {
    val bg = when {
        hovering -> Color(0xFFD6605A).copy(alpha = 0.18f)
        highlighted -> MutedText.copy(alpha = 0.10f)
        else -> Color.Transparent
    }
    val tint = when {
        hovering -> Color(0xFFD6605A)
        highlighted -> MutedText
        else -> GridLine
    }
    Box(
        modifier = modifier
            .height(44.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(bg),
        contentAlignment = Alignment.Center
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                Icons.Filled.KeyboardArrowDown,
                contentDescription = null,
                tint = if (highlighted) tint else MutedText.copy(alpha = 0.5f)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                if (hovering) "Release to send back" else "Drag a placed block here to remove it",
                color = if (highlighted) tint else MutedText.copy(alpha = 0.6f),
                style = MaterialTheme.typography.bodyMedium
            )
        }
    }
}

@Composable
private fun SolvedOverlay(
    levelNumber: Int,
    engine: GameEngine,
    timeMs: Long?,
    attempts: Int?,
    hints: Int?,
    returns: Int?,
    newlyUnlocked: List<Achievement>,
    onNext: () -> Unit,
    onLevelSelect: () -> Unit,
    isLastLevel: Boolean
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(InkBlack.copy(alpha = 0.45f)),
        contentAlignment = Alignment.Center
    ) {
        androidx.compose.animation.AnimatedVisibility(
            visible = true,
            enter = scaleIn(initialScale = 0.85f, animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy)) + fadeIn(),
            exit = scaleOut() + fadeOut()
        ) {
            Column(
                modifier = Modifier
                    .padding(32.dp)
                    .clip(RoundedCornerShape(24.dp))
                    .background(CardSurface)
                    .padding(28.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    modifier = Modifier
                        .size(64.dp)
                        .clip(RoundedCornerShape(32.dp))
                        .background(AccentGold.copy(alpha = 0.18f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Filled.Check, contentDescription = null, tint = AccentGold, modifier = Modifier.size(32.dp))
                }
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    "Solved!",
                    style = MaterialTheme.typography.headlineMedium,
                    color = InkBlack,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    "Level $levelNumber complete",
                    style = MaterialTheme.typography.bodyLarge,
                    color = MutedText
                )
                Spacer(modifier = Modifier.height(18.dp))
                Row(
                    horizontalArrangement = Arrangement.spacedBy(10.dp),
                    modifier = Modifier.horizontalScroll(rememberScrollState())
                ) {
                    if (timeMs != null) {
                        ThinklyChip(text = formatSolveTime(timeMs), background = Paper)
                    }
                    if (attempts != null) {
                        ThinklyChip(text = "$attempts attempt${if (attempts == 1) "" else "s"}", background = Paper)
                    }
                    if (hints != null && hints > 0) {
                        ThinklyChip(text = "$hints hint${if (hints == 1) "" else "s"}", background = Paper)
                    }
                    if (returns != null && returns > 0) {
                        ThinklyChip(text = "$returns removed", background = Paper)
                    }
                }

                if (newlyUnlocked.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(16.dp))
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .background(AccentGold.copy(alpha = 0.12f))
                            .padding(12.dp)
                    ) {
                        Text(
                            "Achievement unlocked!",
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.Bold,
                            color = AccentGold
                        )
                        for (a in newlyUnlocked) {
                            Text(
                                "\u2022 ${a.title} \u2014 ${a.description}",
                                style = MaterialTheme.typography.bodyMedium,
                                color = InkBlack,
                                modifier = Modifier.padding(top = 2.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(24.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    ThinklyButton(
                        text = "Level select",
                        onClick = onLevelSelect,
                        filled = false
                    )
                    ThinklyButton(
                        text = if (isLastLevel) "Done" else "Next level",
                        onClick = onNext,
                        filled = true
                    )
                }
                Spacer(modifier = Modifier.height(10.dp))
                Text(
                    "Share",
                    color = MutedText,
                    fontWeight = FontWeight.SemiBold,
                    style = MaterialTheme.typography.bodyMedium,
                    modifier = Modifier
                        .padding(8.dp)
                        .clickable {
                            ShareCardGenerator.shareSolvedLevel(
                                context = context,
                                levelNumber = levelNumber,
                                engine = engine,
                                timeMs = timeMs,
                                attempts = attempts,
                                hints = hints
                            )
                        }
                )
            }
        }
        ConfettiOverlay()
    }
}

/** Lightweight celebratory confetti: a burst of falling, fading colored shapes.
 * No rotation/physics -- kept simple and quick to finish (~1.6s). */
@Composable
private fun ConfettiOverlay() {
    val particles = remember {
        List(28) {
            ConfettiParticle(
                startXFrac = Random.nextFloat(),
                delayFrac = Random.nextFloat() * 0.3f,
                driftFrac = (Random.nextFloat() - 0.5f) * 0.4f,
                colorIdx = Random.nextInt(PIECE_COLORS.size),
                sizePx = 7f + Random.nextFloat() * 7f,
                isCircle = Random.nextBoolean()
            )
        }
    }
    val progress = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        progress.animateTo(1f, animationSpec = tween(1600, easing = LinearEasing))
    }
    Canvas(modifier = Modifier.fillMaxSize()) {
        val t = progress.value
        for (p in particles) {
            val localT = ((t - p.delayFrac) / (1f - p.delayFrac)).coerceIn(0f, 1f)
            if (localT <= 0f) continue
            val x = (p.startXFrac + p.driftFrac * localT) * size.width
            val y = localT * size.height * 1.05f
            val alpha = (1f - localT * localT).coerceIn(0f, 1f)
            val color = Color(PIECE_COLORS[p.colorIdx]).copy(alpha = alpha)
            if (p.isCircle) {
                drawCircle(color = color, radius = p.sizePx / 2f, center = Offset(x, y))
            } else {
                drawRect(color = color, topLeft = Offset(x - p.sizePx / 2, y - p.sizePx / 2), size = Size(p.sizePx, p.sizePx))
            }
        }
    }
}

private data class ConfettiParticle(
    val startXFrac: Float,
    val delayFrac: Float,
    val driftFrac: Float,
    val colorIdx: Int,
    val sizePx: Float,
    val isCircle: Boolean
)

private fun formatSolveTime(ms: Long): String {
    val totalSec = ms / 1000
    val m = totalSec / 60
    val s = totalSec % 60
    return if (m > 0) "${m}m ${s}s" else "${s}s"
}

private fun formatTimer(totalSeconds: Int): String {
    val m = totalSeconds / 60
    val s = totalSeconds % 60
    return "%d:%02d".format(m, s)
}
