package com.mondrian.puzzle.ui.screens

import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInWindow
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.toSize
import com.mondrian.puzzle.data.PIECE_COLORS
import com.mondrian.puzzle.ui.theme.AccentGold
import com.mondrian.puzzle.ui.theme.CardSurface
import com.mondrian.puzzle.ui.theme.GridLine
import com.mondrian.puzzle.ui.theme.InkBlack
import com.mondrian.puzzle.ui.theme.MutedText
import com.mondrian.puzzle.ui.theme.Paper
import com.mondrian.puzzle.ui.theme.ThinklyButton
import com.mondrian.puzzle.ui.theme.ThinklyChip
import com.mondrian.puzzle.ui.theme.ThinklyHeader
import com.mondrian.puzzle.ui.theme.ThinklyIconButton
import com.mondrian.puzzle.viewmodel.GameViewModel

@Composable
fun GameScreen(
    levelNumber: Int,
    vm: GameViewModel,
    onBack: () -> Unit,
    onNextLevel: (Int) -> Unit
) {
    LaunchedEffect(levelNumber) {
        vm.loadLevel(levelNumber)
    }
    val engine = vm.engine
    // Reading boardVersion here ties GameScreen's recomposition (and therefore the
    // piece tray and win-check) to every placement/rotation/reset mutation, even
    // ones that don't otherwise change dragState.
    @Suppress("UNUSED_VARIABLE") val boardVersionTick = vm.boardVersion

    var rootOriginInWindow by remember { mutableStateOf(Offset.Zero) }
    var boardGeom by remember { mutableStateOf<BoardGeom?>(null) }
    var returnZoneRect by remember { mutableStateOf<Rect?>(null) }

    Column(modifier = Modifier.fillMaxSize().background(Paper)) {
        ThinklyHeader(
            modifier = Modifier.fillMaxWidth(),
            navigationIcon = {
                ThinklyIconButton(Icons.AutoMirrored.Filled.ArrowBack, "Back", onClick = onBack)
            },
            title = {
                Text(
                    "Level $levelNumber",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = InkBlack
                )
            },
            actions = {
                ThinklyIconButton(Icons.Filled.Refresh, "Reset", onClick = { vm.resetLevel() })
            }
        )

        if (engine == null) return@Column

        Box(
            modifier = Modifier
                .fillMaxSize()
                .onGloballyPositioned { rootOriginInWindow = it.positionInWindow() }
        ) {
            val ds = vm.dragState
            val isDraggingFromBoard = ds != null && ds.fromBoard
            val isOverReturnZone = ds != null && returnZoneRect?.contains(ds.fingerPosInWindow) == true

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                BoardView(
                    vm = vm,
                    onGeomChanged = { boardGeom = it },
                    returnZoneRect = returnZoneRect,
                    modifier = Modifier.fillMaxWidth()
                )

                Text(
                    text = "Drag onto the board \u00b7 double-tap to rotate",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MutedText,
                    modifier = Modifier.padding(vertical = 10.dp)
                )

                PieceTray(
                    vm = vm,
                    pieces = vm.unplacedPieces(),
                    boardGeom = boardGeom,
                    boardSize = engine.boardSize,
                    modifier = Modifier.fillMaxWidth().weight(1f, fill = false)
                )

                // Drop target: drag a placed piece here to send it back to the tray.
                // Only meaningfully relevant while dragging a piece that came from
                // the board, so it stays visually quiet the rest of the time.
                ReturnZone(
                    highlighted = isDraggingFromBoard,
                    hovering = isOverReturnZone,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 8.dp)
                        .onGloballyPositioned { coords ->
                            returnZoneRect = Rect(coords.positionInWindow(), coords.size.toSize())
                        }
                )
            }

            // floating ghost of the piece currently being dragged
            if (ds != null && boardGeom != null) {
                val piece = engine.pieces.first { it.piece.id == ds.pieceId }
                val w = piece.piece.width(ds.rotated)
                val h = piece.piece.height(ds.rotated)
                val cellPx = boardGeom!!.cellPx
                val wPx = w * cellPx
                val hPx = h * cellPx
                val topLeftInWindow = ds.fingerPosInWindow - Offset(wPx / 2f, hPx / 2f)
                val localOffset = topLeftInWindow - rootOriginInWindow
                val density = androidx.compose.ui.platform.LocalDensity.current
                val color = Color(PIECE_COLORS[(piece.piece.id - 1) % PIECE_COLORS.size])

                // Subtle "lift" while carrying a piece -- a small, quick scale-up
                // on pickup rather than a constant static ghost.
                val liftScale by animateFloatAsState(
                    targetValue = if (isOverReturnZone) 0.85f else 1.06f,
                    animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy),
                    label = "liftScale"
                )
                val liftedW = wPx * liftScale
                val liftedH = hPx * liftScale
                val centerAdjustX = (wPx - liftedW) / 2f
                val centerAdjustY = (hPx - liftedH) / 2f

                Box(
                    modifier = Modifier
                        .offset(
                            x = with(density) { (localOffset.x + centerAdjustX).toDp() },
                            y = with(density) { (localOffset.y + centerAdjustY).toDp() }
                        )
                        .size(
                            with(density) { liftedW.toDp() },
                            with(density) { liftedH.toDp() }
                        )
                        .clip(RoundedCornerShape(10.dp))
                        .background(color.copy(alpha = if (isOverReturnZone) 0.6f else 0.92f))
                )
            }

            androidx.compose.animation.AnimatedVisibility(
                visible = vm.won,
                enter = fadeIn(),
                exit = fadeOut(),
                modifier = Modifier.fillMaxSize()
            ) {
                SolvedOverlay(
                    levelNumber = levelNumber,
                    timeMs = vm.lastSolveTimeMs,
                    attempts = vm.lastSolveAttempts,
                    onNext = { if (levelNumber < 88) onNextLevel(levelNumber + 1) else onBack() },
                    onLevelSelect = onBack,
                    isLastLevel = levelNumber >= 88
                )
            }
        }
    }
}

@Composable
private fun ReturnZone(highlighted: Boolean, hovering: Boolean, modifier: Modifier = Modifier) {
    val bg = when {
        hovering -> Color(0xFFD6605A).copy(alpha = 0.18f)
        highlighted -> MutedText.copy(alpha = 0.10f)
        else -> Color.Transparent
    }
    val borderColor = when {
        hovering -> Color(0xFFD6605A)
        highlighted -> MutedText
        else -> GridLine
    }
    Box(
        modifier = modifier
            .height(48.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(bg)
            .padding(1.dp),
        contentAlignment = Alignment.Center
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                Icons.Filled.KeyboardArrowDown,
                contentDescription = null,
                tint = if (highlighted) borderColor else MutedText.copy(alpha = 0.5f)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                if (hovering) "Release to send back" else "Drag a placed block here to remove it",
                color = if (highlighted) borderColor else MutedText.copy(alpha = 0.6f),
                style = MaterialTheme.typography.bodyMedium
            )
        }
    }
}

@Composable
private fun SolvedOverlay(
    levelNumber: Int,
    timeMs: Long?,
    attempts: Int?,
    onNext: () -> Unit,
    onLevelSelect: () -> Unit,
    isLastLevel: Boolean
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(InkBlack.copy(alpha = 0.45f)),
        contentAlignment = Alignment.Center
    ) {
        androidx.compose.animation.AnimatedVisibility(
            visible = true,
            enter = scaleIn(initialScale = 0.85f, animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy)) + fadeIn(),
            exit = scaleOut() + fadeOut()
        ) {
            Column(
                modifier = Modifier
                    .padding(32.dp)
                    .clip(RoundedCornerShape(24.dp))
                    .background(CardSurface)
                    .padding(28.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    modifier = Modifier
                        .size(64.dp)
                        .clip(RoundedCornerShape(32.dp))
                        .background(AccentGold.copy(alpha = 0.18f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Filled.Check, contentDescription = null, tint = AccentGold, modifier = Modifier.size(32.dp))
                }
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    "Solved!",
                    style = MaterialTheme.typography.headlineMedium,
                    color = InkBlack,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    "Level $levelNumber complete",
                    style = MaterialTheme.typography.bodyLarge,
                    color = MutedText
                )
                Spacer(modifier = Modifier.height(18.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    if (timeMs != null) {
                        ThinklyChip(text = formatSolveTime(timeMs), background = Paper)
                    }
                    if (attempts != null) {
                        ThinklyChip(text = "$attempts attempt${if (attempts == 1) "" else "s"}", background = Paper)
                    }
                }
                Spacer(modifier = Modifier.height(24.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    ThinklyButton(
                        text = "Level select",
                        onClick = onLevelSelect,
                        filled = false
                    )
                    ThinklyButton(
                        text = if (isLastLevel) "Done" else "Next level",
                        onClick = onNext,
                        filled = true
                    )
                }
            }
        }
    }
}

private fun formatSolveTime(ms: Long): String {
    val totalSec = ms / 1000
    val m = totalSec / 60
    val s = totalSec % 60
    return if (m > 0) "${m}m ${s}s" else "${s}s"
}
