package com.mondrian.puzzle.data

import android.content.Context
import org.json.JSONObject

object LevelRepository {

    private var cache: List<LevelData>? = null

    fun loadLevels(context: Context): List<LevelData> {
        cache?.let { return it }
        val jsonText = context.assets.open("levels.json").bufferedReader().use { it.readText() }
        val root = JSONObject(jsonText)
        val arr = root.getJSONArray("levels")
        val result = mutableListOf<LevelData>()
        for (i in 0 until arr.length()) {
            val obj = arr.getJSONObject(i)
            val blocksArr = obj.getJSONArray("fixed_blocks")
            val blocks = mutableListOf<FixedBlock>()
            for (j in 0 until blocksArr.length()) {
                val b = blocksArr.getJSONObject(j)
                blocks.add(FixedBlock(b.getInt("x"), b.getInt("y"), b.getInt("w"), b.getInt("h")))
            }
            val solutionArr = obj.getJSONArray("solution")
            val solution = mutableListOf<SolutionEntry>()
            for (j in 0 until solutionArr.length()) {
                val s = solutionArr.getJSONObject(j)
                solution.add(SolutionEntry(s.getInt("x"), s.getInt("y"), s.getInt("w"), s.getInt("h")))
            }
            result.add(
                LevelData(
                    level = obj.getInt("level"),
                    board = obj.getInt("board"),
                    difficulty = obj.getString("difficulty"),
                    fixedBlocks = blocks,
                    solution = solution
                )
            )
        }
        cache = result
        return result
    }

    fun getLevel(context: Context, levelNumber: Int): LevelData {
        return loadLevels(context).first { it.level == levelNumber }
    }
}
