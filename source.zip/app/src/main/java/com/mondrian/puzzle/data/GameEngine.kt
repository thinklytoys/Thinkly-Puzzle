package com.mondrian.puzzle.data

/** Cell occupancy: 0 = empty, -1 = fixed block, >0 = movable piece id. */
class GameEngine(val level: LevelData) {

    val boardSize = level.board
    val grid = Array(boardSize) { IntArray(boardSize) }
    val pieces = MOVABLE_PIECES.map { PlacedPiece(it) }.toMutableList()

    init {
        for (b in level.fixedBlocks) {
            for (yy in b.y until b.y + b.h) {
                for (xx in b.x until b.x + b.w) {
                    if (yy in 0 until boardSize && xx in 0 until boardSize) {
                        grid[yy][xx] = -1
                    }
                }
            }
        }
    }

    fun canPlace(piece: PlacedPiece, x: Int, y: Int, rotated: Boolean): Boolean {
        val w = piece.piece.width(rotated)
        val h = piece.piece.height(rotated)
        if (x < 0 || y < 0 || x + w > boardSize || y + h > boardSize) return false
        for (yy in y until y + h) {
            for (xx in x until x + w) {
                if (grid[yy][xx] != 0) return false
            }
        }
        return true
    }

    fun place(piece: PlacedPiece, x: Int, y: Int, rotated: Boolean): Boolean {
        if (!canPlace(piece, x, y, rotated)) return false
        if (piece.placed) removeFromGrid(piece)
        val w = piece.piece.width(rotated)
        val h = piece.piece.height(rotated)
        for (yy in y until y + h) {
            for (xx in x until x + w) {
                grid[yy][xx] = piece.piece.id
            }
        }
        piece.placed = true
        piece.rotated = rotated
        piece.x = x
        piece.y = y
        return true
    }

    fun removeFromGrid(piece: PlacedPiece) {
        if (!piece.placed) return
        val w = piece.piece.width(piece.rotated)
        val h = piece.piece.height(piece.rotated)
        for (yy in piece.y until piece.y + h) {
            for (xx in piece.x until piece.x + w) {
                if (yy in 0 until boardSize && xx in 0 until boardSize && grid[yy][xx] == piece.piece.id) {
                    grid[yy][xx] = 0
                }
            }
        }
        piece.placed = false
    }

    fun pieceAt(x: Int, y: Int): PlacedPiece? {
        val id = grid.getOrNull(y)?.getOrNull(x) ?: return null
        if (id <= 0) return null
        return pieces.firstOrNull { it.piece.id == id }
    }

    fun isFixedAt(x: Int, y: Int): Boolean = grid.getOrNull(y)?.getOrNull(x) == -1

    fun isComplete(): Boolean = grid.all { row -> row.all { it != 0 } }

    fun resetAll() {
        for (p in pieces) removeFromGrid(p)
    }
}
