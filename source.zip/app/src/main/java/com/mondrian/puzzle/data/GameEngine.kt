package com.mondrian.puzzle.data

/** Cell occupancy: 0 = empty, -1 = fixed block, >0 = movable piece id. */
class GameEngine(val level: LevelData) {

    val boardSize = level.board
    val grid = Array(boardSize) { IntArray(boardSize) }
    val pieces = MOVABLE_PIECES.map { PlacedPiece(it) }.toMutableList()

    init {
        for (b in level.fixedBlocks) {
            for (yy in b.y until b.y + b.h) {
                for (xx in b.x until b.x + b.w) {
                    if (yy in 0 until boardSize && xx in 0 until boardSize) {
                        grid[yy][xx] = -1
                    }
                }
            }
        }
    }

    fun canPlace(piece: PlacedPiece, x: Int, y: Int, rotated: Boolean): Boolean {
        val w = piece.piece.width(rotated)
        val h = piece.piece.height(rotated)
        if (x < 0 || y < 0 || x + w > boardSize || y + h > boardSize) return false
        for (yy in y until y + h) {
            for (xx in x until x + w) {
                if (grid[yy][xx] != 0) return false
            }
        }
        return true
    }

    fun place(piece: PlacedPiece, x: Int, y: Int, rotated: Boolean): Boolean {
        if (!canPlace(piece, x, y, rotated)) return false
        if (piece.placed) removeFromGrid(piece)
        val w = piece.piece.width(rotated)
        val h = piece.piece.height(rotated)
        for (yy in y until y + h) {
            for (xx in x until x + w) {
                grid[yy][xx] = piece.piece.id
            }
        }
        piece.placed = true
        piece.rotated = rotated
        piece.x = x
        piece.y = y
        return true
    }

    fun removeFromGrid(piece: PlacedPiece) {
        if (!piece.placed) return
        val w = piece.piece.width(piece.rotated)
        val h = piece.piece.height(piece.rotated)
        for (yy in piece.y until piece.y + h) {
            for (xx in piece.x until piece.x + w) {
                if (yy in 0 until boardSize && xx in 0 until boardSize && grid[yy][xx] == piece.piece.id) {
                    grid[yy][xx] = 0
                }
            }
        }
        piece.placed = false
    }

    fun pieceAt(x: Int, y: Int): PlacedPiece? {
        val id = grid.getOrNull(y)?.getOrNull(x) ?: return null
        if (id <= 0) return null
        return pieces.firstOrNull { it.piece.id == id }
    }

    fun isFixedAt(x: Int, y: Int): Boolean = grid.getOrNull(y)?.getOrNull(x) == -1

    fun isComplete(): Boolean = grid.all { row -> row.all { it != 0 } }

    fun resetAll() {
        for (p in pieces) removeFromGrid(p)
    }

    /** Finds the precomputed solved position/orientation for [piece], matched by
     * its (unordered) shape -- every piece has a distinct {w,h} pair so this is
     * unambiguous regardless of which orientation the solver happened to use. */
    private fun solutionFor(piece: PlacedPiece): SolutionEntry? {
        val targetShape = setOf(piece.piece.baseW, piece.piece.baseH)
        return level.solution.firstOrNull { setOf(it.w, it.h) == targetShape }
    }

    /** True if [piece] is already placed at exactly its solved position/orientation. */
    fun isCorrectlyPlaced(piece: PlacedPiece): Boolean {
        if (!piece.placed) return false
        val sol = solutionFor(piece) ?: return false
        val w = piece.piece.width(piece.rotated)
        val h = piece.piece.height(piece.rotated)
        return piece.x == sol.x && piece.y == sol.y && w == sol.w && h == sol.h
    }

    /** Silently places every piece at its solved position -- used when revisiting
     * a level you've already completed, so it shows solved instead of resetting
     * to blank. Does not go through place()'s normal single-piece bookkeeping
     * concerns since we're filling everything at once from a known-valid layout. */
    fun applyFullSolution() {
        for (p in pieces) {
            val sol = solutionFor(p) ?: continue
            val rotated = sol.w != p.piece.baseW
            if (p.placed) removeFromGrid(p)
            place(p, sol.x, sol.y, rotated)
        }
    }

    /** Applies a hint: finds a piece that isn't yet in its solved position and
     * places it there (bumping anything currently occupying that spot back to
     * unplaced, if needed). Returns the piece that was placed, or null if every
     * piece is already correct (or something unexpected went wrong). */
    fun applyHint(): PlacedPiece? {
        val candidate = pieces.firstOrNull { !isCorrectlyPlaced(it) } ?: return null
        val sol = solutionFor(candidate) ?: return null
        val rotated = sol.w != candidate.piece.baseW

        // Clear anything currently in the way of the hint's target cells (this
        // can include the candidate piece itself if it's misplaced elsewhere).
        for (yy in sol.y until sol.y + sol.h) {
            for (xx in sol.x until sol.x + sol.w) {
                if (yy in 0 until boardSize && xx in 0 until boardSize) {
                    val occupantId = grid[yy][xx]
                    if (occupantId > 0) {
                        val occupant = pieces.firstOrNull { it.piece.id == occupantId }
                        if (occupant != null) removeFromGrid(occupant)
                    }
                }
            }
        }
        if (candidate.placed) removeFromGrid(candidate)
        place(candidate, sol.x, sol.y, rotated)
        return candidate
    }
}
