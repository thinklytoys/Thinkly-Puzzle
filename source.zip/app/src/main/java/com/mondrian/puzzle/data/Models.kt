package com.mondrian.puzzle.data

/** A rectangle placed (or to be placed) on the board, in grid cell units. */
data class FixedBlock(
    val x: Int,
    val y: Int,
    val w: Int,
    val h: Int
)

/** The solved position of one movable piece, precomputed offline so hints can
 * place a piece correctly without needing to re-solve the puzzle on-device. */
data class SolutionEntry(
    val x: Int,
    val y: Int,
    val w: Int,
    val h: Int
)

data class LevelData(
    val level: Int,
    val board: Int,
    val difficulty: String,
    val fixedBlocks: List<FixedBlock>,
    val solution: List<SolutionEntry>
)

/** One of the 8 movable pieces the player places. baseW/baseH are the
 * un-rotated dimensions; rotated toggles which is width vs height. */
data class Piece(
    val id: Int,
    val baseW: Int,
    val baseH: Int
) {
    fun width(rotated: Boolean) = if (rotated) baseH else baseW
    fun height(rotated: Boolean) = if (rotated) baseW else baseH
    val isSquare get() = baseW == baseH
}

/** The full movable piece set, identical for every level. */
val MOVABLE_PIECES = listOf(
    Piece(1, 1, 4),
    Piece(2, 1, 5),
    Piece(3, 2, 2),
    Piece(4, 2, 3),
    Piece(5, 2, 4),
    Piece(6, 2, 5),
    Piece(7, 3, 3),
    Piece(8, 3, 4),
)

/** Runtime placement state for a movable piece within a game session. */
data class PlacedPiece(
    val piece: Piece,
    var placed: Boolean = false,
    var rotated: Boolean = false,
    var x: Int = -1,
    var y: Int = -1
)

/** Soft pastel fill colors (as ARGB long) cycled across the 8 movable pieces,
 * in the spirit of the Almanac app's tile palette. */
val PIECE_COLORS = listOf(
    0xFFF29B9BL, // soft coral
    0xFF8FD4C7L, // seafoam
    0xFFDDA0CFL, // soft orchid
    0xFF8FB7E8L, // periwinkle
    0xFFC7AEF0L, // lavender
    0xFFB9A08CL, // taupe
    0xFFF0C889L, // apricot
    0xFF9CC9A1L, // sage
)

/** Color for the always-fixed obstacle blocks: a warm charcoal, distinct from
 * the pastel movable pieces so they read as "already placed". */
const val FIXED_BLOCK_COLOR = 0xFF3A362FL

