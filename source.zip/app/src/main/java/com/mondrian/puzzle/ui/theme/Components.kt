package com.mondrian.puzzle.ui.theme

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

/** Flat, un-tinted header bar -- avoids Material3's automatic tonal elevation
 * overlay that would otherwise tint TopAppBar a slightly different color than
 * the rest of the (warm, custom) screen. */
@Composable
fun ThinklyHeader(
    modifier: Modifier = Modifier,
    navigationIcon: (@Composable () -> Unit)? = null,
    title: @Composable () -> Unit,
    actions: RowScopeContent = {}
) {
    Row(
        modifier = modifier
            .background(Paper)
            .padding(horizontal = 8.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (navigationIcon != null) {
            Box(modifier = Modifier.size(44.dp), contentAlignment = Alignment.Center) { navigationIcon() }
        }
        Box(modifier = Modifier.weight(1f).padding(start = if (navigationIcon == null) 8.dp else 0.dp)) {
            title()
        }
        Row(verticalAlignment = Alignment.CenterVertically, content = { actions() })
    }
}

typealias RowScopeContent = @Composable () -> Unit

@Composable
fun ThinklyIconButton(
    icon: ImageVector,
    contentDescription: String?,
    onClick: () -> Unit,
    tint: Color = InkBlack
) {
    val interactionSource = remember { MutableInteractionSource() }
    Box(
        modifier = Modifier
            .size(44.dp)
            .clip(CircleShape)
            .clickable(
                interactionSource = interactionSource,
                indication = null,
                onClick = onClick
            ),
        contentAlignment = Alignment.Center
    ) {
        Icon(icon, contentDescription = contentDescription, tint = tint)
    }
}

/** Pill-shaped, branded button used in place of the stock Material3 Button
 * so filled actions match the warm palette instead of Material's defaults. */
@Composable
fun ThinklyButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    filled: Boolean = true
) {
    val bg = if (!enabled) GridLine else if (filled) InkBlack else Color.Transparent
    val fg = if (!enabled) MutedText else if (filled) Paper else InkBlack
    Box(
        modifier = modifier
            .height(48.dp)
            .clip(RoundedCornerShape(24.dp))
            .background(bg)
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 24.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = fg, fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.labelLarge)
    }
}

/** Small rounded chip used for difficulty labels / tags. */
@Composable
fun ThinklyChip(text: String, background: Color, contentColor: Color = InkBlack) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(50))
            .background(background)
            .padding(horizontal = 10.dp, vertical = 4.dp)
    ) {
        Text(
            text,
            color = contentColor,
            style = MaterialTheme.typography.labelLarge,
            maxLines = 1,
            softWrap = false
        )
    }
}
