package com.mondrian.puzzle.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.sqrt

data class SolveRecord(
    val level: Int,
    val difficulty: String,
    val attempts: Int,
    val timeMs: Long,
    val timestamp: Long,
    val hintsUsed: Int = 0,
    val returnsUsed: Int = 0
)

/** Reference solve-time / attempt distributions used to estimate how a solve
 * compares to "typical" players. These are reasonable built-in benchmarks,
 * not live data from other installs -- see StatsScreen copy for the honest
 * framing. Swappable later for a real backend-aggregated distribution. */
private data class Baseline(val meanTimeSec: Double, val sdTimeSec: Double, val meanAttempts: Double, val sdAttempts: Double)

private val BASELINES = mapOf(
    "easy" to Baseline(meanTimeSec = 75.0, sdTimeSec = 35.0, meanAttempts = 1.6, sdAttempts = 0.9),
    "medium" to Baseline(meanTimeSec = 165.0, sdTimeSec = 65.0, meanAttempts = 2.3, sdAttempts = 1.1),
    "hard" to Baseline(meanTimeSec = 280.0, sdTimeSec = 95.0, meanAttempts = 3.1, sdAttempts = 1.3),
)

data class StatsSummary(
    val totalSolved: Int,
    val totalAttempts: Int,
    val totalTimeMs: Long,
    val avgTimeMs: Long,
    val fastestSolveMs: Long?,
    val timePercentile: Int?,      // "faster than X% of typical players"
    val attemptsPercentile: Int?,  // "fewer attempts than X% of typical players"
    val improvementPct: Int?,      // trend: recent solves vs earliest solves
    val totalHints: Int = 0,
    val totalReturns: Int = 0
)

object AnalyticsStore {
    private const val PREFS = "mondrian_analytics"
    private const val KEY_SOLVES = "solve_records"

    fun recordSolve(
        context: Context,
        level: Int,
        difficulty: String,
        attempts: Int,
        timeMs: Long,
        hintsUsed: Int = 0,
        returnsUsed: Int = 0
    ) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val arr = JSONArray(prefs.getString(KEY_SOLVES, "[]"))
        val obj = JSONObject()
        obj.put("level", level)
        obj.put("difficulty", difficulty)
        obj.put("attempts", attempts)
        obj.put("timeMs", timeMs)
        obj.put("timestamp", System.currentTimeMillis())
        obj.put("hintsUsed", hintsUsed)
        obj.put("returnsUsed", returnsUsed)
        arr.put(obj)
        prefs.edit().putString(KEY_SOLVES, arr.toString()).apply()
    }

    fun getAllSolves(context: Context): List<SolveRecord> {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val arr = JSONArray(prefs.getString(KEY_SOLVES, "[]"))
        val list = mutableListOf<SolveRecord>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            list.add(
                SolveRecord(
                    level = o.getInt("level"),
                    difficulty = o.getString("difficulty"),
                    attempts = o.getInt("attempts"),
                    timeMs = o.getLong("timeMs"),
                    timestamp = o.getLong("timestamp"),
                    hintsUsed = o.optInt("hintsUsed", 0),
                    returnsUsed = o.optInt("returnsUsed", 0)
                )
            )
        }
        return list
    }

    /** Most recent solve record for a specific level (if any), used to power
     * the Share button when just viewing (not replaying) a completed level. */
    fun getMostRecentSolveForLevel(context: Context, level: Int): SolveRecord? {
        return getAllSolves(context).filter { it.level == level }.maxByOrNull { it.timestamp }
    }

    fun getStatsSummary(context: Context): StatsSummary {
        val solves = getAllSolves(context)
        if (solves.isEmpty()) {
            return StatsSummary(0, 0, 0, 0, null, null, null, null)
        }
        val totalAttempts = solves.sumOf { it.attempts }
        val totalTime = solves.sumOf { it.timeMs }
        val avgTime = totalTime / solves.size
        val fastest = solves.minOf { it.timeMs }
        val totalHints = solves.sumOf { it.hintsUsed }
        val totalReturns = solves.sumOf { it.returnsUsed }

        // Average percentile across each solve's own difficulty baseline
        val timePercentiles = solves.mapNotNull { s ->
            val b = BASELINES[s.difficulty] ?: return@mapNotNull null
            val z = (s.timeMs / 1000.0 - b.meanTimeSec) / b.sdTimeSec
            100.0 * (1.0 - normalCdf(z))
        }
        val attemptPercentiles = solves.mapNotNull { s ->
            val b = BASELINES[s.difficulty] ?: return@mapNotNull null
            val z = (s.attempts - b.meanAttempts) / b.sdAttempts
            100.0 * (1.0 - normalCdf(z))
        }
        val timePct = timePercentiles.takeIf { it.isNotEmpty() }?.average()?.toInt()?.coerceIn(1, 99)
        val attPct = attemptPercentiles.takeIf { it.isNotEmpty() }?.average()?.toInt()?.coerceIn(1, 99)

        var improvement: Int? = null
        if (solves.size >= 6) {
            val sorted = solves.sortedBy { it.timestamp }
            val firstFew = sorted.take(3).map { it.timeMs.toDouble() / 1000.0 }.average()
            val lastFew = sorted.takeLast(3).map { it.timeMs.toDouble() / 1000.0 }.average()
            if (firstFew > 0) {
                improvement = (((firstFew - lastFew) / firstFew) * 100).toInt()
            }
        }

        return StatsSummary(
            totalSolved = solves.size,
            totalAttempts = totalAttempts,
            totalTimeMs = totalTime,
            avgTimeMs = avgTime,
            fastestSolveMs = fastest,
            timePercentile = timePct,
            attemptsPercentile = attPct,
            improvementPct = improvement,
            totalHints = totalHints,
            totalReturns = totalReturns
        )
    }

    // --- statistics helpers ---

    private fun erf(x: Double): Double {
        val t = 1.0 / (1.0 + 0.3275911 * abs(x))
        val y = 1.0 - ((((1.061405429 * t - 1.453152027) * t + 1.421413741) * t - 0.284496736) * t + 0.254829592) * t * exp(-x * x)
        return if (x >= 0) y else -y
    }

    private fun normalCdf(z: Double): Double {
        return 0.5 * (1.0 + erf(z / sqrt(2.0)))
    }
}
