package com.mondrian.puzzle.viewmodel

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.geometry.Offset
import androidx.lifecycle.AndroidViewModel
import com.mondrian.puzzle.data.AnalyticsStore
import com.mondrian.puzzle.data.GameEngine
import com.mondrian.puzzle.data.LevelRepository
import com.mondrian.puzzle.data.PlacedPiece
import com.mondrian.puzzle.data.ProgressStore

/** Live state of an in-progress drag: which piece, whether it came from the
 * board or the tray, and where the finger currently is (in window/root px).
 * The piece is always centered under the finger while dragging, regardless
 * of where exactly it was grabbed -- this avoids scale-mismatch bugs between
 * the small tray icon and the piece's true (larger) size on the board. */
data class DragState(
    val pieceId: Int,
    val rotated: Boolean,
    val fromBoard: Boolean,
    val originX: Int = -1,
    val originY: Int = -1,
    val fingerPosInWindow: Offset
)

class GameViewModel(application: Application) : AndroidViewModel(application) {

    var engine by mutableStateOf<GameEngine?>(null)
        private set

    var won by mutableStateOf(false)
        private set

    /** Bumped on every board mutation so Compose recomposes the canvas. */
    var boardVersion by mutableIntStateOf(0)
        private set

    var currentLevel by mutableIntStateOf(1)
        private set

    var dragState by mutableStateOf<DragState?>(null)
        private set

    /** Populated the moment a level is solved, for the celebration screen. */
    var lastSolveTimeMs by mutableStateOf<Long?>(null)
        private set
    var lastSolveAttempts by mutableStateOf<Int?>(null)
        private set

    private var levelStartTimeMs: Long = 0L
    private var attemptsThisLevel: Int = 1

    fun loadLevel(levelNumber: Int) {
        val ctx = getApplication<android.app.Application>().applicationContext
        val level = LevelRepository.getLevel(ctx, levelNumber)
        engine = GameEngine(level)
        currentLevel = levelNumber
        dragState = null
        won = false
        levelStartTimeMs = System.currentTimeMillis()
        attemptsThisLevel = 1
        boardVersion++
    }

    // ---- Rotation (double-tap) ----

    /** Double-tap a piece still in the tray: just flips its preview orientation. */
    fun toggleTrayRotation(pieceId: Int) {
        val eng = engine ?: return
        val p = eng.pieces.firstOrNull { it.piece.id == pieceId } ?: return
        if (p.placed || p.piece.isSquare) return
        p.rotated = !p.rotated
        boardVersion++
    }

    /** Double-tap a piece already on the board: rotate in place if it still fits. */
    fun rotatePlacedInPlace(pieceId: Int) {
        val eng = engine ?: return
        val p = eng.pieces.firstOrNull { it.piece.id == pieceId } ?: return
        if (!p.placed || p.piece.isSquare) return
        val ox = p.x
        val oy = p.y
        val newRotated = !p.rotated
        eng.removeFromGrid(p)
        if (!eng.place(p, ox, oy, newRotated)) {
            eng.place(p, ox, oy, !newRotated) // doesn't fit rotated; put back as-is
        }
        boardVersion++
        checkWin()
    }

    /** Send a placed piece back to the tray directly (used when a drag ends over
     * the "return" drop zone below the tray). */
    fun unplacePiece(pieceId: Int) {
        val eng = engine ?: return
        val p = eng.pieces.firstOrNull { it.piece.id == pieceId } ?: return
        if (!p.placed) return
        eng.removeFromGrid(p)
        boardVersion++
    }

    // ---- Drag and drop ----

    fun startDragFromTray(pieceId: Int, fingerPosInWindow: Offset) {
        val eng = engine ?: return
        val p = eng.pieces.firstOrNull { it.piece.id == pieceId } ?: return
        dragState = DragState(pieceId, p.rotated, fromBoard = false, fingerPosInWindow = fingerPosInWindow)
    }

    fun startDragFromBoard(pieceId: Int, fingerPosInWindow: Offset) {
        val eng = engine ?: return
        val p = eng.pieces.firstOrNull { it.piece.id == pieceId } ?: return
        if (!p.placed) return
        val ox = p.x
        val oy = p.y
        eng.removeFromGrid(p)
        boardVersion++
        dragState = DragState(pieceId, p.rotated, fromBoard = true, originX = ox, originY = oy, fingerPosInWindow = fingerPosInWindow)
    }

    fun updateDrag(fingerPosInWindow: Offset) {
        dragState = dragState?.copy(fingerPosInWindow = fingerPosInWindow)
    }

    /** Attempt to drop at the given target top-left board cell (already computed
     * by the caller from the current drag position). Falls back to original
     * position (if from board) or does nothing (if from tray).
     *
     * If [sendToTray] is true (the drag ended over the return-zone drop target),
     * the piece is simply left unplaced -- it was already removed from the grid
     * when the drag started, so this is just "don't put it back." */
    fun endDrag(targetX: Int?, targetY: Int?, sendToTray: Boolean = false) {
        val ds = dragState ?: return
        val eng = engine ?: return
        val p = eng.pieces.firstOrNull { it.piece.id == ds.pieceId } ?: return

        if (sendToTray) {
            dragState = null
            boardVersion++
            return
        }

        var placedOk = false
        if (targetX != null && targetY != null) {
            placedOk = eng.place(p, targetX, targetY, ds.rotated)
        }
        if (!placedOk && ds.fromBoard) {
            eng.place(p, ds.originX, ds.originY, ds.rotated)
        }
        dragState = null
        boardVersion++
        if (placedOk) checkWin()
    }

    fun cancelDrag() {
        val ds = dragState ?: return
        val eng = engine ?: return
        if (ds.fromBoard) {
            val p = eng.pieces.firstOrNull { it.piece.id == ds.pieceId }
            if (p != null) eng.place(p, ds.originX, ds.originY, ds.rotated)
        }
        dragState = null
        boardVersion++
    }

    private fun checkWin() {
        val eng = engine ?: return
        if (eng.isComplete()) {
            won = true
            val ctx = getApplication<android.app.Application>().applicationContext
            ProgressStore.markCompleted(ctx, currentLevel)
            val elapsed = System.currentTimeMillis() - levelStartTimeMs
            lastSolveTimeMs = elapsed
            lastSolveAttempts = attemptsThisLevel
            AnalyticsStore.recordSolve(ctx, currentLevel, eng.level.difficulty, attemptsThisLevel, elapsed)
        }
    }

    fun resetLevel() {
        engine?.resetAll()
        dragState = null
        won = false
        attemptsThisLevel++
        boardVersion++
    }

    fun unplacedPieces(): List<PlacedPiece> = engine?.pieces?.filter { !it.placed } ?: emptyList()
}
