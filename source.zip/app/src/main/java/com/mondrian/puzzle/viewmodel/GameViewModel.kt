package com.mondrian.puzzle.viewmodel

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.geometry.Offset
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.mondrian.puzzle.data.AchievementsStore
import com.mondrian.puzzle.data.Achievement
import com.mondrian.puzzle.data.AnalyticsStore
import com.mondrian.puzzle.data.GameEngine
import com.mondrian.puzzle.data.LevelRepository
import com.mondrian.puzzle.data.PlacedPiece
import com.mondrian.puzzle.data.ProgressStore
import com.mondrian.puzzle.data.SolveRecord
import com.mondrian.puzzle.data.StreakStore
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/** Live state of an in-progress drag: which piece, whether it came from the
 * board or the tray, and where the finger currently is (in window/root px).
 * The piece is always centered under the finger while dragging, regardless
 * of where exactly it was grabbed -- this avoids scale-mismatch bugs between
 * the small tray icon and the piece's true (larger) size on the board. */
data class DragState(
    val pieceId: Int,
    val rotated: Boolean,
    val fromBoard: Boolean,
    val originX: Int = -1,
    val originY: Int = -1,
    val fingerPosInWindow: Offset
)

/** How often (in seconds) a new hint becomes available. */
private const val HINT_INTERVAL_SECONDS = 120

class GameViewModel(application: Application) : AndroidViewModel(application) {

    var engine by mutableStateOf<GameEngine?>(null)
        private set

    var won by mutableStateOf(false)
        private set

    /** Bumped on every board mutation so Compose recomposes the canvas. */
    var boardVersion by mutableIntStateOf(0)
        private set

    var currentLevel by mutableIntStateOf(1)
        private set

    var dragState by mutableStateOf<DragState?>(null)
        private set

    /** Populated the moment a level is solved, for the celebration screen. */
    var lastSolveTimeMs by mutableStateOf<Long?>(null)
        private set
    var lastSolveAttempts by mutableStateOf<Int?>(null)
        private set
    var lastSolveHints by mutableStateOf<Int?>(null)
        private set
    var lastSolveReturns by mutableStateOf<Int?>(null)
        private set

    /** Any achievements newly unlocked by the most recent solve, for a brief
     * celebration on the win screen. Empty most of the time. */
    var newlyUnlockedAchievements by mutableStateOf<List<Achievement>>(emptyList())
        private set

    /** Live timer, ticks once per second while the level is unsolved. */
    var elapsedSeconds by mutableIntStateOf(0)
        private set

    var hintsUsedThisLevel by mutableIntStateOf(0)
        private set
    var returnsThisLevel by mutableIntStateOf(0)
        private set
    var hintAvailable by mutableStateOf(false)
        private set
    /** Briefly set right after a hint is used, so the UI can flash which piece
     * was placed for you. */
    var lastHintedPieceId by mutableStateOf<Int?>(null)
        private set

    /** True when the currently-loaded board is a silent "already solved"
     * snapshot (revisiting a completed level), not a live attempt. The timer
     * doesn't run and hints don't apply in this state; Reset exits it. */
    var isViewingSolvedSnapshot by mutableStateOf(false)
        private set

    /** The persisted stats from the last time this level was actually solved,
     * used to power the Share button while just viewing (not replaying) a
     * completed level. Null while in a live attempt. */
    var viewedLevelSolveRecord by mutableStateOf<SolveRecord?>(null)
        private set

    private var levelStartTimeMs: Long = 0L
    private var attemptsThisLevel: Int = 1
    private var timerJob: Job? = null

    fun loadLevel(levelNumber: Int) {
        val ctx = getApplication<android.app.Application>().applicationContext
        val level = LevelRepository.getLevel(ctx, levelNumber)
        val eng = GameEngine(level)
        engine = eng
        currentLevel = levelNumber
        dragState = null
        won = false
        levelStartTimeMs = System.currentTimeMillis()
        attemptsThisLevel = 1
        elapsedSeconds = 0
        hintsUsedThisLevel = 0
        returnsThisLevel = 0
        hintAvailable = false
        lastHintedPieceId = null
        newlyUnlockedAchievements = emptyList()
        timerJob?.cancel()

        // Revisiting a level you've already solved should show it solved, not
        // reset to blank -- otherwise there's no way to look back at (or show
        // someone) a puzzle you finished. Tap Reset if you want to redo it.
        // While in this snapshot state, the timer doesn't run (nothing to
        // time) and hints don't apply.
        val alreadyCompleted = ProgressStore.getCompletedLevels(ctx).contains(levelNumber)
        if (alreadyCompleted) {
            eng.applyFullSolution()
            isViewingSolvedSnapshot = true
            viewedLevelSolveRecord = AnalyticsStore.getMostRecentSolveForLevel(ctx, levelNumber)
        } else {
            isViewingSolvedSnapshot = false
            viewedLevelSolveRecord = null
            startTimer()
        }
        boardVersion++
    }

    private fun startTimer() {
        timerJob?.cancel()
        timerJob = viewModelScope.launch {
            while (true) {
                delay(1000)
                if (!won) {
                    elapsedSeconds++
                    hintAvailable = elapsedSeconds >= (hintsUsedThisLevel + 1) * HINT_INTERVAL_SECONDS
                }
            }
        }
    }

    // ---- Hints ----

    fun useHint() {
        val eng = engine ?: return
        if (!hintAvailable) return
        val hinted = eng.applyHint() ?: return
        hintsUsedThisLevel++
        lastHintedPieceId = hinted.piece.id
        hintAvailable = false
        boardVersion++
        checkWin()
    }

    // ---- Rotation (double-tap) ----

    /** Double-tap a piece still in the tray: just flips its preview orientation. */
    fun toggleTrayRotation(pieceId: Int) {
        val eng = engine ?: return
        val p = eng.pieces.firstOrNull { it.piece.id == pieceId } ?: return
        if (p.placed || p.piece.isSquare) return
        p.rotated = !p.rotated
        boardVersion++
    }

    /** Double-tap a piece already on the board: rotate in place if it still fits. */
    fun rotatePlacedInPlace(pieceId: Int) {
        val eng = engine ?: return
        val p = eng.pieces.firstOrNull { it.piece.id == pieceId } ?: return
        if (!p.placed || p.piece.isSquare) return
        val ox = p.x
        val oy = p.y
        val newRotated = !p.rotated
        eng.removeFromGrid(p)
        if (!eng.place(p, ox, oy, newRotated)) {
            eng.place(p, ox, oy, !newRotated) // doesn't fit rotated; put back as-is
        }
        boardVersion++
        checkWin()
    }

    /** Send a placed piece back to the tray directly (used when a drag ends over
     * the "return" drop zone below the tray). */
    fun unplacePiece(pieceId: Int) {
        val eng = engine ?: return
        val p = eng.pieces.firstOrNull { it.piece.id == pieceId } ?: return
        if (!p.placed) return
        eng.removeFromGrid(p)
        returnsThisLevel++
        boardVersion++
    }

    // ---- Drag and drop ----

    fun startDragFromTray(pieceId: Int, fingerPosInWindow: Offset) {
        val eng = engine ?: return
        val p = eng.pieces.firstOrNull { it.piece.id == pieceId } ?: return
        dragState = DragState(pieceId, p.rotated, fromBoard = false, fingerPosInWindow = fingerPosInWindow)
    }

    fun startDragFromBoard(pieceId: Int, fingerPosInWindow: Offset) {
        val eng = engine ?: return
        val p = eng.pieces.firstOrNull { it.piece.id == pieceId } ?: return
        if (!p.placed) return
        val ox = p.x
        val oy = p.y
        eng.removeFromGrid(p)
        boardVersion++
        dragState = DragState(pieceId, p.rotated, fromBoard = true, originX = ox, originY = oy, fingerPosInWindow = fingerPosInWindow)
    }

    fun updateDrag(fingerPosInWindow: Offset) {
        dragState = dragState?.copy(fingerPosInWindow = fingerPosInWindow)
    }

    /** Attempt to drop at the given target top-left board cell (already computed
     * by the caller from the current drag position). Falls back to original
     * position (if from board) or does nothing (if from tray).
     *
     * If [sendToTray] is true (the drag ended over the return-zone drop target),
     * the piece is simply left unplaced -- it was already removed from the grid
     * when the drag started, so this is just "don't put it back."
     *
     * Returns true if the drag resulted in a meaningful outcome (placed, or sent
     * back), so the caller can decide whether e.g. haptic feedback is warranted. */
    fun endDrag(targetX: Int?, targetY: Int?, sendToTray: Boolean = false): Boolean {
        val ds = dragState ?: return false
        val eng = engine ?: return false
        val p = eng.pieces.firstOrNull { it.piece.id == ds.pieceId } ?: return false

        if (sendToTray) {
            returnsThisLevel++
            dragState = null
            boardVersion++
            return true
        }

        var placedOk = false
        if (targetX != null && targetY != null) {
            placedOk = eng.place(p, targetX, targetY, ds.rotated)
        }
        if (!placedOk && ds.fromBoard) {
            eng.place(p, ds.originX, ds.originY, ds.rotated)
        }
        dragState = null
        boardVersion++
        if (placedOk) checkWin()
        return placedOk
    }

    fun cancelDrag() {
        val ds = dragState ?: return
        val eng = engine ?: return
        if (ds.fromBoard) {
            val p = eng.pieces.firstOrNull { it.piece.id == ds.pieceId }
            if (p != null) eng.place(p, ds.originX, ds.originY, ds.rotated)
        }
        dragState = null
        boardVersion++
    }

    private fun checkWin() {
        val eng = engine ?: return
        if (eng.isComplete()) {
            won = true
            timerJob?.cancel()
            com.mondrian.puzzle.data.SoundPlayer.playWin()
            val ctx = getApplication<android.app.Application>().applicationContext
            ProgressStore.markCompleted(ctx, currentLevel)
            val streak = StreakStore.recordPlayToday(ctx)
            val elapsed = System.currentTimeMillis() - levelStartTimeMs
            lastSolveTimeMs = elapsed
            lastSolveAttempts = attemptsThisLevel
            lastSolveHints = hintsUsedThisLevel
            lastSolveReturns = returnsThisLevel
            AnalyticsStore.recordSolve(
                ctx, currentLevel, eng.level.difficulty, attemptsThisLevel, elapsed,
                hintsUsed = hintsUsedThisLevel, returnsUsed = returnsThisLevel
            )
            newlyUnlockedAchievements = AchievementsStore.checkAfterSolve(
                context = ctx,
                totalSolved = ProgressStore.getCompletedLevels(ctx).size,
                hintsUsedThisLevel = hintsUsedThisLevel,
                attemptsThisLevel = attemptsThisLevel,
                solveTimeMs = elapsed,
                currentStreak = streak
            )
        }
    }

    fun resetLevel() {
        engine?.resetAll()
        dragState = null
        won = false
        attemptsThisLevel++
        isViewingSolvedSnapshot = false
        viewedLevelSolveRecord = null
        elapsedSeconds = 0
        hintsUsedThisLevel = 0
        returnsThisLevel = 0
        hintAvailable = false
        lastHintedPieceId = null
        levelStartTimeMs = System.currentTimeMillis()
        startTimer()
        boardVersion++
    }

    fun unplacedPieces(): List<PlacedPiece> = engine?.pieces?.filter { !it.placed } ?: emptyList()

    override fun onCleared() {
        super.onCleared()
        timerJob?.cancel()
    }
}
