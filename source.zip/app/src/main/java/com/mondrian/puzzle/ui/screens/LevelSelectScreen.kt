package com.mondrian.puzzle.ui.screens

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.HelpOutline
import androidx.compose.material.icons.filled.Insights
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.mondrian.puzzle.R
import com.mondrian.puzzle.data.FixedBlock
import com.mondrian.puzzle.data.LevelRepository
import com.mondrian.puzzle.data.ProgressStore
import com.mondrian.puzzle.data.StreakStore
import com.mondrian.puzzle.ui.theme.AccentGold
import com.mondrian.puzzle.ui.theme.InkBlack
import com.mondrian.puzzle.ui.theme.MutedText
import com.mondrian.puzzle.ui.theme.Paper
import com.mondrian.puzzle.ui.theme.ThinklyHeader
import com.mondrian.puzzle.ui.theme.ThinklyIconButton

/** Same tiers used across the app (levels.json), reproduced here as a simple
 * numeric rule so the level-select grid can tint tiles without loading the
 * full level dataset. */
private fun difficultyColorFor(level: Int): Color = when {
    level <= 30 -> Color(0xFF9CC9A1) // sage - Starter
    level <= 60 -> Color(0xFF8FB7E8) // periwinkle - Skilled
    else -> Color(0xFFF29B9B)        // coral - Expert
}

@Composable
fun LevelSelectScreen(
    onLevelSelected: (Int) -> Unit,
    onOpenHelp: () -> Unit,
    onOpenStats: () -> Unit
) {
    val context = LocalContext.current
    val completed = remember { ProgressStore.getCompletedLevels(context) }
    val streak = remember { StreakStore.getCurrentStreak(context) }
    val levels = remember { LevelRepository.loadLevels(context) }
    val fixedBlocksByLevel = remember { levels.associate { it.level to it.fixedBlocks } }

    Column(modifier = Modifier.fillMaxSize().background(Paper)) {
        ThinklyHeader(
            modifier = Modifier.fillMaxWidth(),
            title = {
                Image(
                    painter = painterResource(id = R.drawable.logo_thinkly),
                    contentDescription = "Thinkly",
                    modifier = Modifier.height(30.dp)
                )
            },
            actions = {
                if (streak > 0) {
                    Row(
                        modifier = Modifier.padding(end = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            Icons.Filled.LocalFireDepartment,
                            contentDescription = "Streak",
                            tint = AccentGold,
                            modifier = Modifier.height(20.dp)
                        )
                        Text(
                            "$streak",
                            color = InkBlack,
                            fontWeight = FontWeight.Bold,
                            style = MaterialTheme.typography.bodyLarge,
                            modifier = Modifier.padding(start = 2.dp, end = 6.dp)
                        )
                    }
                }
                ThinklyIconButton(Icons.Filled.Insights, "Your stats", onClick = onOpenStats)
                ThinklyIconButton(Icons.AutoMirrored.Filled.HelpOutline, "How to play", onClick = onOpenHelp)
            }
        )

        LazyVerticalGrid(
            columns = GridCells.Fixed(5),
            contentPadding = PaddingValues(12.dp),
            modifier = Modifier
                .fillMaxSize()
        ) {
            item(span = { GridItemSpan(maxLineSpan) }) {
                Column(modifier = Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 8.dp)) {
                    Text(
                        text = "88 Stages",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = InkBlack
                    )
                    Text(
                        text = "${completed.size} of 88 solved \u00b7 Starter to Expert",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MutedText,
                        modifier = Modifier.padding(top = 2.dp, bottom = 4.dp)
                    )
                }
            }
            items(88) { idx ->
                val level = idx + 1
                val unlocked = level == 1 || completed.contains(level - 1)
                val isDone = completed.contains(level)
                val tint = difficultyColorFor(level)
                LevelTile(
                    level = level,
                    unlocked = unlocked,
                    isDone = isDone,
                    fixedBlocks = fixedBlocksByLevel[level] ?: emptyList(),
                    tint = tint,
                    onClick = { onLevelSelected(level) }
                )
            }
        }
    }
}

@Composable
private fun LevelTile(
    level: Int,
    unlocked: Boolean,
    isDone: Boolean,
    fixedBlocks: List<FixedBlock>,
    tint: Color,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .padding(6.dp)
            .aspectRatio(1f)
            .clip(RoundedCornerShape(14.dp))
            .background(if (unlocked) tint.copy(alpha = if (isDone) 0.9f else 0.35f) else MutedText.copy(alpha = 0.12f))
            .clickable(enabled = unlocked) { onClick() }
    ) {
        if (unlocked) {
            // tiny preview of this level's fixed-block pattern, doubling as
            // visual texture so the grid doesn't read as plain numbered tiles
            Canvas(modifier = Modifier.fillMaxSize().padding(7.dp)) {
                val cell = size.width / 8f
                val blockColor = if (isDone) Color.White.copy(alpha = 0.6f) else InkBlack.copy(alpha = 0.55f)
                for (b in fixedBlocks) {
                    drawRoundRect(
                        color = blockColor,
                        topLeft = Offset(b.x * cell, b.y * cell),
                        size = Size(b.w * cell, b.h * cell),
                        cornerRadius = CornerRadius(cell * 0.3f, cell * 0.3f)
                    )
                }
            }
            Text(
                text = level.toString(),
                color = if (isDone) Color.White else InkBlack,
                fontWeight = if (isDone) FontWeight.Bold else FontWeight.Medium,
                fontSize = 11.sp,
                modifier = Modifier.align(Alignment.BottomEnd).padding(5.dp)
            )
        } else {
            Icon(
                Icons.Filled.Lock,
                contentDescription = "Locked",
                tint = MutedText,
                modifier = Modifier.align(Alignment.Center).padding(4.dp)
            )
        }
    }
}
